## 11. Notes for authors before submission (removed from the manuscript)

These notes were moved out of the manuscript so that it contains no internal editorial comments.

### Topic statement (for the authors' records; not part of the manuscript)

**Topic.** Conformal prediction for classification when the class proportions change between training and deployment (label shift) and the importance weights that correct for it have to be estimated from unlabelled target data.

**Why this topic.** Weighted conformal prediction can, in principle, restore coverage under label shift, but its guarantee assumes the true class weights. In practice the weights are estimated, sometimes from only a few hundred unlabelled points. This paper bounds the coverage lost to weight error, turns the bound into a new procedure (bound-corrected weighted conformal prediction with a Mondrian fallback), and tests it under both simulated label shift and a natural geographic shift. The natural-shift result marks clearly where label-shift guarantees stop, which matters for anyone deploying uncertainty estimates in changing environments.

### Author names

Name order follows Elsevier practice (given name first, without tone marks): Zhāng Chén = Chen Zhang, Huáng Wú = Wu Huang, Sòng Xiè = Xie Song. Check the affiliation against the official English name on the university's website.

ORCIDs are entered for each author in Editorial Manager; they are not needed in the manuscript file.

### Institutional statement (for internal use)

**Institutional statement:** This work was carried out at the College of Artificial Intelligence, Tsinghua University, as part of an MSc research project in machine learning. All experiments use public benchmark datasets. No human participants, patient data or personal data were involved.

### Highlights

Each highlight is at most 85 characters including spaces. Upload them as a separate file (Highlights.docx).

### CRediT roles

Draft role assignment: each author must confirm or correct their roles so that they match what they actually did. Elsevier uses the 14 CRediT roles; see https://www.elsevier.com/researcher/author/policies-and-guidelines/credit-author-statement.

### Competing interests

If any author has a relevant interest (consulting, patents, employment with a company that sells uncertainty-quantification products, etc.), replace the sentence above with a description. Elsevier's submission system generates the formal declaration file from a short questionnaire.

### Ethics

No consent template is needed because no human or medical data were used. If the method is later applied to clinical data, approval from the institutional ethics committee and a consent or waiver statement must be added.

### Generative-AI declaration

Check that this description matches how the tool was actually used and edit it if needed. This wording follows Elsevier's template (https://www.elsevier.com/about/policies-and-standards/generative-ai-policies-for-journals, accessed 2026-10-10). It is required, not optional. Do not remove it or understate the assistance.

### Data availability

If you create a GitHub repository and Zenodo DOI before submission, add them to the Data availability statement.
