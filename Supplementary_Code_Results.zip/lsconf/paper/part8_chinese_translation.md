## 10. Simplified Chinese translation of the title and abstract (for institutional use only)

*This is a translation for internal or institutional use, for example a university research record. It is **not** part of the manuscript submitted to the journal and should not be uploaded with it. It was machine-assisted and should be checked by a native speaker, for example a Chinese co-author, before any use. It corresponds to the version-3 abstract.*

**标题（译文）：** 基于估计标签偏移权重的共形预测：覆盖率界、界校正加权方法，以及模拟偏移与自然偏移下的实证证据

**作者：** Spencer Brown，张晨（Zhāng Chén），黄吾（Huáng Wú），宋谢（Sòng Xiè）

**单位：** 清华大学人工智能学院，北京 100084，中国

*Note: the Chinese characters for the three Chinese names were inferred from the pinyin and may be wrong, because many characters share the same pinyin. Each author must replace them with the correct characters.*

**摘要（译文）：**

**背景：** 共形预测为分类器提供与分布无关的覆盖率保证，但当训练与部署阶段的类别比例发生变化（标签偏移）时，该保证会失效。对校准数据加权只有在类别权重已知时才能恢复有效性，而实际中这些权重必须估计。

**方法：** 我们证明了由估计权重导致的覆盖率损失受其总变差误差的约束。在此基础上，界校正加权共形预测利用自助法对权重误差的估计相应收紧误覆盖水平，并在权重过于不确定时回退到类条件（Mondrian）预测。我们还提出了一种收缩规则。在五个基准数据集上，于狄利克雷标签偏移下（30个随机种子，五项消融实验），以及在完整Covertype数据的自然地理偏移下，对各方法进行了比较。

**结果：** 在模拟偏移下，分割共形预测的覆盖率降至0.707（目标为0.90），而Mondrian预测在全部20种设置中的平均覆盖率均不低于0.90。界校正方法的欠覆盖频率从未高于Mondrian预测。其自助法误差估计在8–39%的抽样中低于真实权重误差，但由此产生的覆盖率超额项平均不超过0.003。在仅有500个无标签样本时，它很少给出比Mondrian预测更小的预测集。在无偏移时，收缩使权重误差降低0.059–0.085。在一个违反标签偏移假设的自然偏移数据集中，所有方法（包括使用真实类别比例加权的方法）的覆盖率仅为0.70–0.83。

**结论：** 界校正为使用估计权重提供了一种审慎且近似保持理论保证的方式；但所有标签偏移校正都依赖于一个需要事先检验的假设。

**意义：** 本研究阐明了标签偏移校正在共形预测中何时可以信赖。
