## 12. Point-by-point response to the second internal review

*This section records how each point of the second (internal, pre-submission) review was addressed. Section and table numbers refer to the revised manuscript (version 3).*

**Comment 1.** *Resolve the inconsistency between the number of experimental methods in the results files and those reported in Table 2, and ensure that all tables, scripts, datasets and reported sample counts match.*

**Response.** We agree; the inconsistency was real. The text described the main results file as "14,000 rows … 7 methods" after two methods (WCP-BBSE-BC and WCP-MLLS-BC) had been added, and the ablation files had been produced before the new methods existed. We re-ran every ablation with the current code, so all result files now contain the same nine methods. The only exception is the fixed-shrinkage ablation, which by design runs BBSE only. The original methods' results were reproduced bit for bit. We also wrote `scripts/check_consistency.py`, which checks, for every results file, the row count implied by its design (datasets × seeds × shift levels × draws × methods), the method set, duplicates, the row counts quoted in the text, table and figure placement and numbering, citation keys, and coverage by `run_all.sh`. All 82 checks pass in the submitted version.

**Change in manuscript.** Section 6 (row counts), Section 5.4 (method list), all tables regenerated; new script in the repository.

**Comment 2.** *The bootstrap threshold estimates uncertainty in the weights but does not guarantee an upper bound on their true error; prove the guarantee rigorously or describe it as approximate and evaluate it empirically.*

**Response.** We agree, and we did both. Section 4 now separates what is exact from what is approximate. Proposition 5 is an exact inequality for any $t$ computed from the estimation data. A new Corollary 1 shows that the nominal level holds whenever $t$ is a valid upper confidence bound. A new paragraph ("What is and is not guaranteed") states that our bootstrap quantile is not shown to be such a bound, because it ignores bias, its consistency is not established, and it cannot detect violations of the label-shift assumption. The guarantee of the bound-corrected methods is therefore described throughout as approximate. Empirically (new Table 6), the bootstrap quantile fell below the true weight error in 8–39% of draws, against a design target of 10%. This confirms the concern. The resulting excess term was nevertheless at most 0.0027 on average per setting, and the average coverage stayed between 0.900 and 0.944. We also point to a rigorous alternative, propagating finite-sample confidence intervals as in Si et al. (2024), as future work.

**Change in manuscript.** Section 3.7, Section 4 (Proposition 5, Corollary 1, new paragraph), Appendix B (proof of Corollary 1), Section 6.3 and Table 6, Abstract, Introduction (contribution 2).

**Comment 3.** *Clarify whether the coverage result is marginal or conditional on the calibration data; increase the number of seeds if feasible; report statistical tests and effect sizes more transparently.*

**Response.** Section 4 now opens with a paragraph defining the probability space. All guarantees are marginal over the calibration sample and the test point, conditional on the estimation data; none is calibration-conditional (PAC). We also explain how the per-seed coverage in the experiments relates to these quantities. The main experiment was extended from 10 to 30 seeds and the natural-shift experiment from 5 to 10. Every paired comparison now reports the mean difference with a bootstrap 95% CI, the rank-biserial correlation $r_{rb}$, Cohen's $d_z$, the raw and Holm-adjusted *p*-values, and the size of each test family. After Holm correction, 29 of 40 weight-error, 44 of 120 coverage, 58 of 120 set-size and 52 of 120 worst-class comparisons are significant. The main effects have |r_rb| ≥ 0.9, and the text points out where significant differences are too small to matter.

**Change in manuscript.** Sections 4, 5.5, 6.4; Tables 7 and A4; all seed counts.

**Comment 4.** *Explain precisely how the method differs from existing label-shift correction and conformal prediction approaches.*

**Response.** Section 2 now contains a comparison table (Table 1) and a paragraph stating the differences. Podkopaev and Ramdas (2021) give exact validity with known weights and asymptotic validity with consistent estimated weights, and separately propose label-conditional prediction. Si et al. (2024) give PAC guarantees by propagating confidence intervals. RLLS regularises the weight estimator for weighted training. We correct our earlier attribution: Proposition 2 is standard and is credited to Vovk (2013), Sadinle et al. (2019) and Podkopaev and Ramdas (2021), and we removed the inaccurate statement that the Mondrian baseline is often left out of label-shift studies. Our contributions are stated as a non-asymptotic bound (Proposition 3), a single procedure that uses it to decide between weighting and label-conditional prediction (Proposition 5), a shrinkage rule, and the experimental evidence.

**Change in manuscript.** Section 1 (contribution 1), Section 2 (new paragraph and Table 1), Section 4 (attributions).

**Comment 5.** *Acknowledge more clearly that the natural-shift experiment shows under-coverage when the label-shift assumption is violated, and avoid generalising from a single dataset.*

**Response.** Done. The Abstract, Highlights, Introduction (scope paragraph), Section 6.6, Section 8.4 and the Conclusion now describe it as one dataset with one kind of (geographic) shift, in which every method under-covered (coverage 0.70–0.83). We do not claim that every natural shift breaks these methods. We claim only that their guarantees depend on the label-shift assumption, which should be checked.

**Change in manuscript.** Abstract, Highlight 4, Sections 1, 6.6, 8.4, 9.

**Comment 6.** *Correct numbering and presentation issues, remove internal editorial notes, and verify references, figures, tables and reproducibility materials.*

**Response.** Tables are now numbered 1–18 in order of first appearance, with Appendix Tables A1–A4; figures are numbered 1–6 in order. Fig. 1 now appears where it is first cited. All internal notes (topic statement, name-order note, ORCID and highlight notes, bracketed instructions in the declarations) were removed from the manuscript and moved to Section 11 of this package. The data-availability statement no longer contains placeholders. All 42 references were re-checked against Crossref, arXiv and OpenAlex, and each is cited. The consistency script (Comment 1) verifies the remaining items.

**Change in manuscript.** Throughout.
