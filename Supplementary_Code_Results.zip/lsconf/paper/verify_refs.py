"""Check every entry of refs.bib against public indexes (no API key, no email).

DOI   -> https://api.crossref.org/works/<doi>
arXiv -> https://export.arxiv.org/api/query?id_list=<id>
other -> https://api.openalex.org/works?search=<title>

Prints the title returned by the index and a fuzzy title-match score, and
writes paper/refs_verification.csv. A low score means: check by hand.
"""
import csv
import difflib
import json
import re
import sys
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

UA = {"User-Agent": "lsconf-reference-check/0.1 (academic, no-email)"}


def get(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.read().decode("utf-8")


def parse_bib(text):
    entries = []
    for m in re.finditer(r"@(\w+)\{([^,]+),(.*?)\n\}", text, re.S):
        fields = dict((k.lower(), v.strip()) for k, v in
                      re.findall(r"(\w+)\s*=\s*\{(.*?)\},?\s*\n", m.group(3) + "\n", re.S))
        fields["key"] = m.group(2).strip()
        entries.append(fields)
    return entries


def clean(t):
    t = re.sub(r"[{}\\'`\"~^]", "", t)
    return re.sub(r"\s+", " ", t).strip().lower()


def main(path):
    rows = []
    for e in parse_bib(open(path, encoding="utf-8").read()):
        title, src, found, extra = e.get("title", ""), "", "", ""
        try:
            if "doi" in e:
                src = "crossref"
                msg = json.loads(get("https://api.crossref.org/works/" + urllib.parse.quote(e["doi"])))["message"]
                found = (msg.get("title") or [""])[0]
                extra = f"{msg.get('container-title', [''])[0] if msg.get('container-title') else ''} {msg.get('issued', {}).get('date-parts', [['']])[0][0]}"
            elif "eprint" in e:
                src = "arxiv"
                xml = get("https://export.arxiv.org/api/query?id_list=" + e["eprint"])
                ns = {"a": "http://www.w3.org/2005/Atom"}
                ent = ET.fromstring(xml).find("a:entry", ns)
                found = ent.find("a:title", ns).text if ent is not None else ""
                extra = ent.find("a:published", ns).text[:4] if ent is not None else ""
            else:
                src = "openalex"
                js = json.loads(get("https://api.openalex.org/works?per-page=1&search=" + urllib.parse.quote(clean(title))))
                if js["results"]:
                    found = js["results"][0]["display_name"]
                    extra = f"{js['results'][0].get('publication_year')} doi={js['results'][0].get('doi')}"
        except Exception as ex:  # network or parse problem -> report, never guess
            found, extra = "", f"ERROR {type(ex).__name__}: {ex}"
        score = difflib.SequenceMatcher(None, clean(title), clean(found or "")).ratio()
        status = "OK" if score >= 0.9 else ("CHECK" if found else "UNRESOLVED")
        rows.append(dict(key=e["key"], source=src, status=status, score=round(score, 3),
                         bib_title=title, index_title=re.sub(r"\s+", " ", found or ""), extra=extra))
        shown = re.sub(r"\s+", " ", found or "")[:80]
        print(f"{status:10s} {score:.2f} {e['key']:28s} {src:8s} | {shown} | {extra}", flush=True)
        time.sleep(0.4)
    with open(path.replace("refs.bib", "refs_verification.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


if __name__ == "__main__":
    main(sys.argv[1])
