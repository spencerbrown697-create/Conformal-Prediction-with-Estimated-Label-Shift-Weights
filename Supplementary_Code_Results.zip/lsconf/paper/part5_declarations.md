## CRediT authorship contribution statement

**Spencer Brown:** Conceptualization, Methodology, Software, Investigation, Formal analysis, Visualization, Writing – original draft. **Chen Zhang:** Data curation, Validation, Software, Writing – review & editing. **Wu Huang:** Methodology, Formal analysis, Writing – review & editing. **Xie Song:** Conceptualization, Supervision, Project administration, Writing – review & editing.

## Declaration of competing interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

## Funding

This research did not receive any specific grant from funding agencies in the public, commercial, or not-for-profit sectors.

## Data availability

All datasets used in this study are publicly available: optical digits (UCI, via scikit-learn `load_digits`), pendigits (OpenML 32, https://www.openml.org/d/32), satimage (OpenML 182, https://www.openml.org/d/182), letter (OpenML 6, https://www.openml.org/d/6) and Covertype (UCI, https://archive.ics.uci.edu/dataset/31). The code, random seeds, raw per-draw results (CSV), analysis scripts and logs needed to reproduce every table and figure are provided as supplementary material with this submission (Supplementary_Code_Results.zip) and will be deposited in a public repository with a persistent identifier upon acceptance.

## Ethics statement

This study uses only public, de-identified benchmark datasets of handwritten characters, satellite image features, synthetic letter images and cartographic variables. It involves no human participants, no animals, no patient data and no personal data, so ethical approval and informed consent were not required.

## Declaration of generative AI and AI-assisted technologies in the manuscript preparation process

During the preparation of this work the author(s) used Claude (Anthropic) to draft and edit the manuscript text, write and run the experiment and analysis code on the authors' computer, and check reference metadata. Every reported number is produced by the released scripts from the raw result files. After using this tool, the author(s) reviewed and edited the content as needed and take(s) full responsibility for the content of the published article.

## Acknowledgements

The authors thank the maintainers of the UCI Machine Learning Repository, OpenML and scikit-learn for making the data and software freely available.
