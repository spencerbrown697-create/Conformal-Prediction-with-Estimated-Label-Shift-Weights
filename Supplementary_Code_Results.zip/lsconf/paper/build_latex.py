"""Convert the Markdown manuscript parts into an elsarticle LaTeX source.

    python paper/build_latex.py      -> paper/latex/main.tex (+ refs.bib, figures)

Compile with:  pdflatex main && bibtex main && pdflatex main && pdflatex main
"""
from __future__ import annotations

import os
import re
import shutil

SRC = ["paper/part1_front_intro_method.md", "paper/part2_setup.md",
       "paper/part3_results_discussion.md", "paper/part5_declarations.md"]
APPX = "paper/part4_appendix.md"
OUT_DIR = "paper/latex"


def load_tables():
    txt = open("paper/tables_generated.md", encoding="utf-8").read()
    return {m.group(1): (m.group(2).strip(), m.group(3).strip())
            for m in re.finditer(r"### (Table [A0-9]+[ab]?)\. (.*?)\n(.*?)(?=\n### |\Z)", txt, re.S)}


def esc(s):
    """Escape text outside math."""
    parts = re.split(r"(\$\$.*?\$\$|\$[^$]+\$)", s)
    out = []
    for p in parts:
        if p.startswith("$"):
            out.append(p)
            continue
        p = p.replace("\\", "\\textbackslash{}")
        for a, b in [("&", "\\&"), ("%", "\\%"), ("#", "\\#"), ("_", "\\_"), ("~", "\\textasciitilde{}")]:
            p = p.replace(a, b)
        def _cite(m):
            items = [k.strip().lstrip("@") for k in m.group(1).split(";")]
            if len(items) == 1 and "," in items[0]:
                key, note = [x.strip() for x in items[0].split(",", 1)]
                return "\\cite[" + note + "]{" + key + "}"
            return "\\cite{" + ",".join(items) + "}"
        p = re.sub(r"\[(@[^\]]+)\]", _cite, p)
        p = re.sub(r"\*\*(.+?)\*\*", r"\\textbf{\1}", p)
        p = re.sub(r"(?<![\w*])\*([^*\s][^*]*?)\*(?!\w)", r"\\emph{\1}", p)
        p = re.sub(r"`([^`]+)`", r"\\texttt{\1}", p)
        p = re.sub(r"\^([^^\s]+)\^", r"\\textsuperscript{\1}", p)
        p = p.replace("–", "--").replace("—", "---").replace("±", "$\\pm$").replace("≤", "$\\le$")
        p = p.replace("κ̂", "$\\hat\\kappa$").replace("κ", "$\\kappa$").replace("−", "$-$").replace("×", "$\\times$")
        p = p.replace("☐", "$\\square$").replace("½", "$\\frac12$")
        out.append(p)
    return "".join(out)


def table_tex(rows, caption=None, label=None):
    hdr = [c.strip() for c in rows[0].strip().strip("|").split("|")]
    body = [[c.strip() for c in r.strip().strip("|").split("|")] for r in rows[2:]]
    L = ["\\begin{table}[!htbp]\\centering\\scriptsize"]
    if caption:
        L.append(f"\\caption{{{esc(caption)}}}" + (f"\\label{{{label}}}" if label else ""))
    L.append("\\resizebox{\\textwidth}{!}{\\begin{tabular}{" + "l" * len(hdr) + "}\\toprule")
    L.append(" & ".join(esc(h) for h in hdr) + " \\\\ \\midrule")
    for r in body:
        L.append(" & ".join(esc(c) for c in r) + " \\\\")
    L.append("\\bottomrule\\end{tabular}}\\end{table}")
    return "\n".join(L)


def convert(text, tables):
    out, lines, i = [], text.split("\n"), 0
    in_list = None
    while i < len(lines):
        s = lines[i].strip()

        def close_list():
            nonlocal in_list
            if in_list:
                out.append(f"\\end{{{in_list}}}")
                in_list = None
        if not s or s.startswith("<!--"):
            close_list()
            i += 1
            continue
        if s.startswith("```"):
            close_list()
            j = i + 1
            code = []
            while not lines[j].strip().startswith("```"):
                code.append(lines[j])
                j += 1
            out.append("{\\footnotesize\\begin{verbatim}\n" + "\n".join(code) + "\n\\end{verbatim}}")
            i = j + 1
            continue
        if s.startswith("$$"):
            close_list()
            eq = s[2:]
            j = i
            while not eq.rstrip().endswith("$$"):
                j += 1
                eq += "\n" + lines[j].strip()
            out.append("\\begin{equation*}" + eq.rstrip()[:-2] + "\\end{equation*}")
            i = j + 1
            continue
        m = re.match(r"\{\{TABLE:(.+?)\}\}", s)
        if m:
            close_list()
            cap, body = tables[m.group(1)]
            rows = [r for r in body.split("\n") if r.startswith("|")]
            notes = " ".join(r for r in body.split("\n") if r and not r.startswith("|"))
            out.append(table_tex(rows, (cap + " " + notes).strip(), "tab:" + m.group(1).split()[-1]))
            i += 1
            continue
        m = re.match(r"\{\{FIG:(.+?)\|(.+)\}\}", s)
        if m:
            close_list()
            cap = re.sub(r"^\*\*Fig\. \d+\.\*\*\s*", "", m.group(2))
            out.append("\\begin{figure}[!htbp]\\centering\\includegraphics[width=\\textwidth]{" + m.group(1) +
                       ".png}\\caption{" + esc(cap) + "}\\end{figure}")
            i += 1
            continue
        if s.startswith("|"):
            close_list()
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                rows.append(lines[i])
                i += 1
            out.append(table_tex(rows))
            continue
        h = re.match(r"(#{1,4}) (.*)", s)
        if h:
            close_list()
            lvl, title = len(h.group(1)), re.sub(r"^[A-Z]?\d+(\.\d+)*\.?\s+|^Appendix [A-Z]\.\s*", "", h.group(2))
            numbered = bool(re.match(r"^([A-Z]?\d+(\.\d+)*\.?\s|Appendix [A-Z]\.)", h.group(2)))
            cmd = {2: "section", 3: "subsection", 4: "subsubsection"}.get(lvl)
            if cmd and not numbered:
                cmd += "*"
            if cmd:
                out.append(f"\\{cmd}{{{esc(title)}}}")
            i += 1
            continue
        lm = re.match(r"^(\d+\.|[-*]) (.*)", s)
        if lm:
            kind = "enumerate" if lm.group(1)[0].isdigit() else "itemize"
            if in_list != kind:
                close_list()
                out.append(f"\\begin{{{kind}}}")
                in_list = kind
            out.append("\\item " + esc(lm.group(2)))
            i += 1
            continue
        close_list()
        buf = [s]
        while i + 1 < len(lines) and lines[i + 1].strip() and not re.match(
                r"^(#|\||```|\$\$|\{\{|- |\* |\d+\. )", lines[i + 1].strip()):
            i += 1
            buf.append(lines[i].strip())
        out.append(esc(" ".join(buf)) + "\n")
        i += 1
    if in_list:
        out.append(f"\\end{{{in_list}}}")
    return "\n".join(out)


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    tables = load_tables()
    body = ""
    front = open(SRC[0], encoding="utf-8").read()
    # drop the front-matter blocks handled by the elsarticle frontmatter
    main_from = front.index("## 1. Introduction")
    abstract = re.search(r"## Abstract\n\n(.*?)\n## Keywords", open(SRC[2], encoding="utf-8").read()
                         if "## Abstract" in open(SRC[2], encoding="utf-8").read() else front, re.S)
    highlights = re.findall(r"^\d\. (.+)$", front[front.index("## Highlights"):front.index("## Abstract")], re.M)
    keywords = re.search(r"## Keywords\n\n(.+)", front).group(1).split("; ")
    body += convert(front[main_from:], tables)
    for p in SRC[1:]:
        t = open(p, encoding="utf-8").read()
        t = re.sub(r"## Abstract.*?(?=\n## (?!Abstract))", "", t, flags=re.S)
        t = re.sub(r"## Simplified Chinese translation.*?(?=\n## |\Z)", "", t, flags=re.S)
        body += "\n" + convert(t, tables)
    appendix = convert(open(APPX, encoding="utf-8").read(), tables)
    title = re.search(r"^# (.+)$", front, re.M).group(1)
    abs_raw = abstract.group(1).split("*Simplified Chinese")[0].strip() if abstract else "[ABSTRACT]"
    abs_text = esc(abs_raw)
    hl_tex = "\n".join(r"\item " + esc(h) for h in highlights)
    kw_tex = r" \sep ".join(keywords)
    title_tex = esc(title)
    tex = rf"""\documentclass[review,12pt]{{elsarticle}}
\usepackage{{amsmath,amssymb,booktabs,graphicx,lineno,hyperref}}
\usepackage[utf8]{{inputenc}}
\linenumbers
\journal{{Artificial Intelligence}}
\begin{{document}}
\begin{{frontmatter}}
\title{{{esc(title)}}}
\author[a]{{Spencer Brown\corref{{cor1}}}}
\ead{{spencerbrown697@gmail.com}}
\author[a]{{Chen Zhang}}
\author[a]{{Wu Huang}}
\author[a]{{Xie Song}}
\cortext[cor1]{{Corresponding author}}
\affiliation[a]{{organization={{College of Artificial Intelligence, Tsinghua University}}, city={{Beijing}}, postcode={{100084}}, country={{China}}}}
\begin{{abstract}}
{abs_text}
\end{{abstract}}
\begin{{highlights}}
{hl_tex}
\end{{highlights}}
\begin{{keyword}}
{kw_tex}
\end{{keyword}}
\end{{frontmatter}}
{body}
\bibliographystyle{{elsarticle-num}}
\bibliography{{refs}}
\appendix
{appendix}
\end{{document}}
"""
    open(os.path.join(OUT_DIR, "main.tex"), "w", encoding="utf-8").write(tex)
    shutil.copy("paper/refs.bib", OUT_DIR)
    for f in os.listdir("figures"):
        if f.endswith(".png"):
            shutil.copy(os.path.join("figures", f), OUT_DIR)
    print("wrote", os.path.join(OUT_DIR, "main.tex"))


if __name__ == "__main__":
    main()
