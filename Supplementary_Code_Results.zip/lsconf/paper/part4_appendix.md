## Appendix A. Algorithm

**Algorithm 1.** Weighted conformal prediction with bootstrap-shrunk label-shift weights (WCP-BBSE-S / WCP-MLLS-S).

```
Input : classifier f with probabilities p(.|x); source class proportions pi
        labelled source set E = {(x_j, y_j)}            (for BBSE only)
        calibration set {(X_i, Y_i)}, i = 1..n
        unlabelled target sample U = {u_1..u_m}
        miscoverage alpha, bootstrap size B, score function s
Output: prediction set C(x) for any target input x

 1: w_hat <- ESTIMATE(E, U)                 # BBSE: solve C w = mu; MLLS: EM
 2: w_hat <- clip(w_hat, 0); w_hat <- w_hat / (pi . w_hat)
 3: for b = 1..B:
 4:     E*, U* <- resample E and U with replacement   (MLLS: U only)
 5:     w*_b  <- ESTIMATE(E*, U*), clipped and normalised as in line 2
 6: v_hat  <- sum_y pi_y * Var_b(w*_{b,y})
 7: d2_hat <- sum_y pi_y * (w_hat_y - 1)^2
 8: kappa  <- max(0, 1 - v_hat / d2_hat)    (kappa = 0 if d2_hat = 0)
 9: w_S    <- 1 + kappa * (w_hat - 1)
10: S_i <- s(X_i, Y_i) for i = 1..n; sort the scores and carry the weights w_S[Y_i] along
11: for each label k = 1..K:
12:     t_k <- smallest S_(j) with  sum_{l<=j} w_S[Y_(l)] / (sum_i w_S[Y_i] + w_S[k]) >= 1 - alpha
13:            (t_k = +infinity if no such j exists)
14: return C(x) = { k : s(x, k) <= t_k }
```

**Algorithm 2.** Bound-corrected weighted CP with Mondrian fallback (WCP-BBSE-BC / WCP-MLLS-BC).

```
Input : w_hat and bootstrap replicates w*_1..w*_B from Algorithm 1 (lines 1-5),
        calibration scores, source proportions pi, alpha, delta (default 0.1)
1: for b = 1..B:  e_b <- 0.5 * sum_y pi_y * |w*_{b,y} - w_hat_y|
2: t <- (1 - delta) quantile of e_1..e_B
3: if t > alpha / 2:  return Mondrian CP sets at level alpha        # fallback
4: else:              return weighted CP sets (Algorithm 1, lines 10-14)
                      with weights w_hat at level alpha - t
```

## Appendix B. Proofs

**Proof of Proposition 1 (sketch).** This is Theorem 2 of [@tibshirani2019covariate] specialised to label shift, as in [@podkopaev2021labelshift]. Under label shift, $(Z_1,\dots,Z_n)\sim P$ i.i.d. and $Z_{n+1}\sim Q$ are weighted exchangeable with weight function $w(z)=w_y$ for $z=(x,y)$. Conditional on the multiset of the $n+1$ scores, the test score is distributed as $\sum_{i=1}^{n+1} p_i\delta_{V_i}$ with $p_i\propto w(Z_i)$ [@tibshirani2019covariate, Lemma 3]. Replacing the unknown test score in this distribution by $+\infty$ only increases the quantile, which gives $Q\big(S_{n+1}\le \hat t^{(Y_{n+1})}\big)\ge1-\alpha$. Since $Y_{n+1}\in C_w(X_{n+1})$ is exactly this event, the claim follows. $\square$

**Proof of Proposition 2.** Condition on the calibration labels. The $n_y$ calibration scores of class $y$ are i.i.d. draws from the distribution of $s(X,y)$ given $Y=y$ under $P$. A test point of class $y$ has a score from the same distribution, because $Q(x\mid y)=P(x\mid y)$. These $n_y+1$ scores are exchangeable, so the usual split-conformal argument [@vovk2013conditional; @lei2018distribution] gives $\Pr(Y\in C_{\mathrm M}(X)\mid Y=y)\ge1-\alpha$, and this holds under both $P$ and $Q$. (If $\lceil(n_y+1)(1-\alpha)\rceil>n_y$, then $\hat t_y=\infty$ and coverage is 1.) Averaging over the target labels gives $Q(Y\in C_{\mathrm M}(X))=\sum_y q_y\Pr(Y\in C_{\mathrm M}(X)\mid Y=y)\ge1-\alpha$. $\square$

**Proof of Proposition 3.** Fix $\hat w$; it is independent of everything else, so we may treat it as constant. Define the distribution $\hat Q$ by $\hat Q(x\mid y)=P(x\mid y)$ and $\hat Q(Y=y)=\pi_y\hat w_y$. This is a valid distribution because $\hat w\ge0$ and $\sum_y\pi_y\hat w_y=1$. Relative to $P$, $\hat Q$ is a label shift with exact weights $\hat w$. Proposition 1 applied to $\hat Q$ therefore gives $\mathbb E_D\big[\hat Q(A_D)\big]\ge1-\alpha$, where $D$ is the calibration data and $A_D=\{(x,y):y\in C_{\hat w}(x)\}$ is the coverage event for the set built from $D$. For each fixed $D$, $|Q(A_D)-\hat Q(A_D)|\le d_{\mathrm{TV}}(Q,\hat Q)$. Since $Q$ and $\hat Q$ share the conditional $P(x\mid y)$,
$$d_{\mathrm{TV}}(Q,\hat Q)=\tfrac12\sum_y\big|q_y-\pi_y\hat w_y\big|\int P(dx\mid y)=\tfrac12\sum_y\pi_y|w_y-\hat w_y|.$$
Hence $\mathbb E_D[Q(A_D)]\ge\mathbb E_D[\hat Q(A_D)]-d_{\mathrm{TV}}(Q,\hat Q)\ge1-\alpha-\tfrac12\sum_y\pi_y|w_y-\hat w_y|$. $\square$

**Proof of Proposition 4.** Write $a=\|w-\mathbf 1\|_\pi^2$. Then $\hat w_\kappa-w=(1-\kappa)(\mathbf 1-w)+\kappa\varepsilon$, and
$$\mathbb E\|\hat w_\kappa-w\|_\pi^2=(1-\kappa)^2a+\kappa^2v+2\kappa(1-\kappa)\,\mathbb E\langle\mathbf 1-w,\varepsilon\rangle_\pi=(1-\kappa)^2a+\kappa^2v,$$
because $\mathbb E\varepsilon=0$. Setting the derivative $-2(1-\kappa)a+2\kappa v$ to zero gives $\kappa^\star=a/(a+v)\in[0,1]$. Substituting, the minimum is $a\big(\tfrac{v}{a+v}\big)^2+v\big(\tfrac{a}{a+v}\big)^2=\tfrac{av}{a+v}$, which is at most $\min(a,v)$. For the last statement, since $\sum_y\pi_y=1$, the Cauchy–Schwarz inequality gives $\sum_y\pi_y|e_y|\le(\sum_y\pi_ye_y^2)^{1/2}$ for any vector $e$. Jensen's inequality ($\mathbb E\sqrt X\le\sqrt{\mathbb E X}$) then gives $\mathbb E\,\tfrac12\sum_y\pi_y|\hat w_{\kappa,y}-w_y|\le\tfrac12(\mathbb E\|\hat w_\kappa-w\|_\pi^2)^{1/2}$. $\square$

**Proof of Proposition 5.** Condition on $(\hat w,t)$, which are independent of the calibration and test data. If $t>\alpha/2$, the set is Mondrian CP at level $\alpha$, whose coverage under any label shift is at least $1-\alpha$ by Proposition 2. If $t\le\alpha/2$, the set is weighted CP with weights $\hat w$ at level $\alpha-t$. Proposition 3 applied at that level gives conditional coverage at least $1-(\alpha-t)-\mathrm{TV}(\hat w)=1-\alpha-(\mathrm{TV}(\hat w)-t)\ge1-\alpha-(\mathrm{TV}(\hat w)-t)_+$. Combining the two cases and taking the expectation over $(\hat w,t)$ gives the claim. $\square$

**Proof of Corollary 1.** $\mathrm{TV}(\hat w)$ is a total-variation distance between two probability distributions, so it lies in $[0,1]$, and therefore $(\mathrm{TV}(\hat w)-t)_+\le\mathbf 1\{\mathrm{TV}(\hat w)>t\}$. Hence the excess term in Proposition 5 is at most $\Pr\{\mathrm{TV}(\hat w)>t\}\le\delta$. If $t\ge\mathrm{TV}(\hat w)$ almost surely, the excess term is zero. $\square$

## Appendix C. Computational complexity

Let $n$ be the calibration size, $n_e$ the size of the labelled estimation set, $m$ the size of the unlabelled target sample, $m_e$ the number of test points, $K$ the number of classes, $B$ the number of bootstrap replicates and $T$ the number of EM iterations. Table A1 lists the cost of each step.

**Table A1.** Computational cost of each step (notation as above).

| Step | Time | Memory |
|---|---|---|
| Sort calibration scores | $O(n\log n)$ | $O(n)$ |
| $K$ weighted thresholds (cumulative sums) | $O(Kn)$ | $O(n)$ |
| Prediction sets for $m_e$ test points | $O(m_eK)$ | $O(m_eK)$ |
| BBSE (confusion matrix + least squares) | $O(n_e+m+K^3)$ | $O(K^2)$ |
| MLLS (EM) | $O(TmK)$ | $O(mK)$ |
| Bootstrap shrinkage | $B\times$ the estimator's cost | $O(BK)$ |

Shrinkage adds a factor of $B$ to the cost of weight estimation and nothing to the cost of building prediction sets. In our runs, the average wall-clock time for all weight estimation per shift draw (BBSE, MLLS and both bootstraps with $B=100$) ranged from 0.29 s on digits to 2.96 s on letter (column `t_weights` of the raw results).

## Appendix D. Hyperparameters and seeds

Table A2 lists every hyperparameter, seed and evaluation setting used in the experiments.

**Table A2.** Hyperparameters, seeds and evaluation settings.

| Item | Value |
|---|---|
| Split fractions (train / est / cal / pool) | 0.5 / 0.1 / 0.2 / 0.2, stratified |
| Split seed for seed index $s$ | $1000s$, $s=0,\dots,29$ (main); $s=0,\dots,9$ (natural shift); $s=0,\dots,4$ (ablations) |
| Main classifier | StandardScaler + LogisticRegression ($C=1$, lbfgs, max_iter 3000) |
| Ablation classifier | HistGradientBoosting (max_iter 200, lr 0.1, early_stopping False, random_state $s$) |
| Score (main / ablation) | LAC / randomised APS (uniform draws seeded with $10000+s$) |
| $\alpha$ (main / ablation) | 0.1 / 0.05, 0.2 |
| Shift levels | none; Dirichlet $c\in\{10,1,0.1\}$ |
| Draws per seed and shift | 10 (generator seeded with (seed, shift index, draw)) |
| Unlabelled target size $m$ (main / ablation) | 500 / 100, 300, 1000, 3000 |
| Evaluation sample size | 2,000 |
| Bootstrap replicates $B$ | 100 |
| MLLS stopping rule | max change $<10^{-8}$ or 500 iterations (200 inside the bootstrap) |
| Under-coverage tolerance | coverage $<1-\alpha-0.02$ |
| Minimum class size for worst-class coverage | 20 evaluation points |
| Statistical tests | Wilcoxon signed-rank (two-sided, zsplit), Holm within metric; bootstrap 95% CI (10,000 resamples, seed 0) |


## Appendix E. Additional result tables

Table A3 gives the worst-class coverage behind Section 6.2, and Table A4 lists the pre-specified paired comparisons for coverage, set size and weight error behind Section 6.4, with effect sizes and raw and Holm-adjusted p-values. Both are generated from `results/tables/` by `scripts/make_tables.py`.

{{TABLE:Table A3}}

{{TABLE:Table A4}}
