# Revision notes: version 3 (11 October 2026)

This version addresses the second internal review. A point-by-point response is in Section 12 of the submission package. Version 2 is archived unchanged, with SHA-256 checksums in `revisions/v2/SHA256SUMS.txt` (version-2 manuscript: `a14884423b9fdf50…`).

## Main changes

1. **Consistency of results, tables and text.**
   - Every ablation was re-run with the current code, so all result files contain the same nine methods (the fixed-shrinkage ablation runs BBSE only, by design).
   - All previously reported rows were reproduced bit for bit.
   - The row counts in the text now match the files: 54,000 main rows and 2,700 natural-shift rows.
   - Table captions now take their seed and test counts from the data.
   - The new `scripts/check_consistency.py` runs 82 checks (row counts against the design, method sets, duplicates, table and figure placement and numbering, citations, quoted counts, coverage by `run_all.sh`). All pass.
2. **Accurate theory.**
   - Section 4 now states the probability space: every guarantee is marginal over the calibration data, given the estimation data, and none is calibration-conditional.
   - Proposition 5 is kept as an exact inequality. The new Corollary 1 gives the nominal guarantee when t is a valid upper confidence bound.
   - The bootstrap t is explicitly described as *not* such a bound, so the bound-corrected methods are called approximate.
   - New Table 6 measures this: t fell below the true weight error in 8–39% of draws per setting for MLLS (target 10%), but the excess coverage term averaged at most 0.0027.
3. **More seeds and transparent statistics.**
   - The main experiment now uses 30 seeds (was 10) and the natural-shift experiment 10 (was 5).
   - Every test reports the mean difference with a bootstrap CI, rank-biserial r, Cohen's d_z, raw and Holm p, and the size of its family.
   - Holm-significant results: 29 of 40 weight-error, 44 of 120 coverage, 58 of 120 set-size and 52 of 120 worst-class comparisons.
4. **Novelty stated precisely.**
   - New comparison table (Table 1) and paragraph in Section 2.
   - Corrected attribution: the Mondrian approach under label shift was already proposed by Podkopaev and Ramdas, whose estimated-weight guarantee is asymptotic. The earlier claim that Mondrian is "often left out" was removed.
5. **Natural shift framed as one dataset.**
   - The abstract, highlights, introduction, Section 6.6, the limitations and the conclusion now say that this one dataset shows under-coverage when the label-shift assumption is violated, without generalising.
6. **Presentation.**
   - Tables are numbered 1–18 and A1–A4, and figures 1–6, all in order of appearance. Fig. 1 moved to the method section.
   - All internal editorial notes were moved out of the manuscript (package Section 11), and no placeholders remain in the manuscript.
   - The Chinese translation was updated to the new abstract.

## Still to be completed by the authors

- Submission date in the cover letter.
- Confirmation of the CRediT roles, the Chinese name characters and the Editors-in-Chief.
- ORCIDs, entered in Editorial Manager.
- A public repository link and DOI, if available before submission.
