"""Assemble the manuscript .docx from the Markdown parts.

    python paper/build_docx.py            (run from the repository root)

* [@key; @key2] citations -> numbered [1,2] in order of first appearance
  (Elsevier numbered style); the reference list is generated from refs.bib.
* {{TABLE:Table 2}} is replaced by that table from paper/tables_generated.md.
* {{FIG:name|caption}} inserts figures/name.png with its caption.
* $...$ and $$...$$ math is converted to Unicode text with sub/superscripts.
"""
from __future__ import annotations

import re
import sys

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

PARTS = ["paper/part1_front_intro_method.md", "paper/part2_setup.md",
         "paper/part3_results_discussion.md", "paper/part5_declarations.md", "@REFERENCES", "paper/part4_appendix.md"]
OUT = sys.argv[1] if len(sys.argv) > 1 else "paper/Manuscript_LabelShift_Conformal.docx"
if len(sys.argv) > 2:  # custom part list, e.g. for the submission package
    PARTS = sys.argv[2:]

# ------------------------------------------------------------------ bib
ACCENTS = [(r"{\\`e}", "è"), (r"{\\'e}", "é"), (r'{\\"o}', "ö"), (r'{\\"u}', "ü"), (r'{\\"a}', "ä"),
           (r"{\\'i}", "í"), (r"{\\~n}", "ñ"), (r"{\\v{s}}", "š"), (r"{\\'E}", "É"), (r'{\\"e}', "ë")]


def detex(s):
    for a, b in ACCENTS:
        s = s.replace(a.replace("\\\\", "\\"), b)
    s = s.replace("--", "–").replace("\\&", "&")
    return re.sub(r"[{}]", "", s).strip()


def parse_bib(path):
    text = open(path, encoding="utf-8").read()
    out = {}
    for m in re.finditer(r"@(\w+)\{([^,]+),(.*?)\n\}", text, re.S):
        f = {k.lower(): v for k, v in re.findall(r"(\w+)\s*=\s*\{(.*?)\},?\s*\n", m.group(3) + "\n", re.S)}
        f["type"] = m.group(1).lower()
        out[m.group(2).strip()] = f
    return out


def names(field):
    res = []
    for a in field.split(" and "):
        a = detex(a)
        if "," in a:
            last, first = [x.strip() for x in a.split(",", 1)]
        else:
            parts = a.split()
            last, first = parts[-1], " ".join(parts[:-1])
        initials = " ".join(p[0] + "." if not p.endswith(".") else p
                            for p in re.split(r"\s+", first) if p) if first else ""
        initials = re.sub(r"(\w)\.-?(\w)", r"\1.-\2", initials) if "-" in first else initials
        if "-" in first and " " not in first.strip():  # e.g. Zhi-Hua -> Z.-H.
            initials = "-".join(x[0] + "." for x in first.split("-"))
        res.append(f"{initials} {last}".strip())
    return ", ".join(res)


def fmt_ref(e):
    who = names(e["author"]) if "author" in e else names(e["editor"]) + " (Eds.)"
    t, y = detex(e["title"]), e.get("year", "")
    doi = f" https://doi.org/{e['doi']}." if "doi" in e else ""
    arx = f" arXiv:{e['eprint']}." if "eprint" in e else ""
    if e["type"] == "article":
        vol = e.get("volume", "")
        pages = detex(e.get("pages", ""))
        s = f"{who}, {t}, {detex(e['journal'])} {vol} ({y})" + (f" {pages}" if pages else "") + "."
    elif e["type"] == "book":
        ed = f", {e['edition']}nd ed." if e.get("edition") == "2" else ""
        addr = f", {e['address']}" if "address" in e else ""
        s = f"{who}, {t}{ed}, {detex(e['publisher'])}{addr}, {y}."
    else:
        pages = f", pp. {detex(e['pages'])}" if "pages" in e else ""
        s = f"{who}, {t}, in: {detex(e['booktitle'])}{pages}, {y}."
    return s + doi + (arx if not doi else "")


# ------------------------------------------------------------------ math -> unicode
SYM = {r"\alpha": "α", r"\kappa": "κ", r"\pi": "π", r"\varepsilon": "ε", r"\delta": "δ", r"\mu": "μ",
       r"\le": "≤", r"\ge": "≥", r"\sum": "Σ", r"\in": "∈", r"\odot": "⊙", r"\infty": "∞", r"\cdot": "·",
       r"\dots": "…", r"\lceil": "⌈", r"\rceil": "⌉", r"\mid": " ∣ ", r"\|": "‖", r"\langle": "⟨",
       r"\rangle": "⟩", r"\star": "⋆", r"\times": "×", r"\approx": "≈", r"\to": "→", r"\quad": "    ",
       r"\qquad": "      ", r"\{": "", r"\}": "", r"\square": "□", r"\sqrt": "√", r"\,": " ",
       r"\tfrac12": "½", r"\frac12": "½", r"\Big": "", r"\big": "", r"\left": "", r"\right": "",
       r"\neq": "≠", r"\log": "log", r"\ldots": "…", r"\prime": "′"}


SYM.update({r"\sim": "∼", r"\Pr": "Pr", r"\ne": "≠", r"\le": "≤", r"\ge": "≥"})


def latex_to_unicode(s):
    s = re.sub(r"\\widehat\{\\mathrm\{Var\}\}", "V̂ar", s)
    greek = {"kappa": "κ", "alpha": "α", "pi": "π", "mu": "μ", "varepsilon": "ε", "delta": "δ"}
    s = re.sub(r"\\hat\s*(?:\{\\(\w+)\}|\\(\w+))",
               lambda m: greek.get(m.group(1) or m.group(2), m.group(0)) + "\u0302", s)
    s = re.sub(r"\\mathbf\s*(?:\{1\}|1)", "𝟏", s)
    s = re.sub(r"\\mathbb\s*(?:\{E\}|E)", "𝔼", s)
    s = re.sub(r"\\mathcal\s*(?:\{X\}|X)", "𝒳", s)
    s = re.sub(r"\\hat\s*(?:\{([A-Za-z])\}|([A-Za-z]))", lambda m: (m.group(1) or m.group(2)) + "\u0302", s)
    s = re.sub(r"\\frac\{([^{}]*)\}\{([^{}]*)\}", r"(\1)/(\2)", s)
    s = re.sub(r"\\sqrt\{([^{}]*)\}", r"√(\1)", s)
    # symbols first; the "no letter follows" guard (to keep \in apart from \infty)
    # applies only to commands whose name ends in a letter, not to \{ \} \| \,
    for k in sorted(SYM, key=len, reverse=True):
        guard = r"(?![A-Za-z])" if k[-1].isalpha() else ""
        s = re.sub(re.escape(k) + guard, SYM[k], s)
    # text-style commands last, so a symbol directly before them is already converted
    s = re.sub(r"\\(?:mathrm|text|operatorname)\{([^{}]*)\}", r"\1", s)
    s = re.sub(r"\\mathrm\s*([A-Za-z])", r"\1", s)
    s = s.replace("~", " ")
    return s


def math_runs(s):
    """Split converted math into runs with sub/superscript flags."""
    s = latex_to_unicode(s)
    runs, i, buf = [], 0, ""
    while i < len(s):
        c = s[i]
        if c in "_^":
            if buf:
                runs.append((buf, None))
                buf = ""
            kind = "sub" if c == "_" else "sup"
            i += 1
            if i < len(s) and s[i] == "{":
                depth, j = 1, i + 1
                while j < len(s) and depth:
                    depth += {"{": 1, "}": -1}.get(s[j], 0)
                    j += 1
                inner = s[i + 1:j - 1]
                i = j
            else:
                inner = s[i] if i < len(s) else ""
                i += 1
            inner = inner.replace("{", "").replace("}", "").replace("_", "").replace("^", "")
            runs.append((inner, kind))
        elif c in "{}":
            i += 1
        else:
            buf += c
            i += 1
    if buf:
        runs.append((buf, None))
    fix = str.maketrans({"": "{", "": "}"})
    return [(re.sub(r"  +", " ", t.translate(fix)), k) for t, k in runs]


# ------------------------------------------------------------------ inline markdown
TOKEN = re.compile(r"(\$[^$]+\$|\*\*[^*]+\*\*|\*[^*\s][^*]*\*|`[^`]+`|\^[^^\s]+\^)")


def add_inline(p, text, base_bold=False, size=None):
    for part in TOKEN.split(text):
        if not part:
            continue
        if part.startswith("$"):
            for t, kind in math_runs(part[1:-1]):
                r = p.add_run(t)
                r.font.subscript = kind == "sub"
                r.font.superscript = kind == "sup"
                r.bold = base_bold
                if size:
                    r.font.size = size
        elif part.startswith("**"):
            add_inline(p, part[2:-2], True, size)
        elif part.startswith("`"):
            r = p.add_run(part[1:-1])
            r.font.name = "Consolas"
            r.font.size = Pt(10)
        elif part.startswith("^") and part.endswith("^"):
            r = p.add_run(part[1:-1])
            r.font.superscript = True
        elif part.startswith("*"):
            r = p.add_run(part[1:-1])
            r.italic = True
            r.bold = base_bold
            if size:
                r.font.size = size
        else:
            r = p.add_run(part)
            r.bold = base_bold
            if size:
                r.font.size = size


# ------------------------------------------------------------------ citations
order: dict[str, int] = {}


def cite_sub(m):
    keys = [k.strip().lstrip("@").split(",")[0] for k in m.group(1).split(";")]
    nums = []
    for k in keys:
        if k not in order:
            order[k] = len(order) + 1
        nums.append(order[k])
    nums = sorted(set(nums))
    # compress runs: 3,4,5 -> 3–5
    out, start, prev = [], nums[0], nums[0]
    for n in nums[1:] + [None]:
        if n is not None and n == prev + 1:
            prev = n
            continue
        out.append(f"{start}–{prev}" if prev - start >= 2 else (f"{start},{prev}" if prev != start else f"{start}"))
        if n is not None:
            start = prev = n
    return "[" + ",".join(out) + "]"


CITE = re.compile(r"\[(@[^\]]+)\]")


# ------------------------------------------------------------------ build
def set_cell_text(cell, text, bold=False):
    cell.text = ""
    p = cell.paragraphs[0]
    add_inline(p, text, bold, Pt(8))


def add_table(doc, rows):
    hdr = [c.strip() for c in rows[0].strip().strip("|").split("|")]
    body = [[c.strip() for c in r.strip().strip("|").split("|")] for r in rows[2:]]
    t = doc.add_table(rows=1, cols=len(hdr))
    t.style = "Table Grid"
    for c, h in zip(t.rows[0].cells, hdr):
        set_cell_text(c, h, True)
    for r in body:
        cells = t.add_row().cells
        for c, v in zip(cells, r):
            set_cell_text(c, v)
    doc.add_paragraph()


def load_tables():
    txt = open("paper/tables_generated.md", encoding="utf-8").read()
    blocks = {}
    for m in re.finditer(r"### (Table [A0-9]+[ab]?)\. (.*?)\n(.*?)(?=\n### |\Z)", txt, re.S):
        blocks[m.group(1)] = (m.group(2).strip(), m.group(3).strip())
    return blocks


def line_numbering(section):
    ln = OxmlElement("w:lnNumType")
    ln.set(qn("w:countBy"), "1")
    ln.set(qn("w:restart"), "continuous")
    section._sectPr.append(ln)


def main():
    bib = parse_bib("paper/refs.bib")
    tables = load_tables()
    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "SimSun")
    st.font.size = Pt(12)
    st.paragraph_format.line_spacing = 1.5
    st.paragraph_format.space_after = Pt(6)
    for h in ("Heading 1", "Heading 2", "Heading 3", "Title"):
        doc.styles[h].font.name = "Times New Roman"
        doc.styles[h].font.color.rgb = RGBColor(0, 0, 0)
    sec = doc.sections[0]
    sec.left_margin = sec.right_margin = Cm(2.5)
    line_numbering(sec)

    # first pass: collect text and assign citation numbers in reading order
    texts = []
    for p in PARTS:
        if p == "@REFERENCES":
            texts.append(p)
            continue
        t = open(p, encoding="utf-8").read()
        t = CITE.sub(cite_sub, t)
        texts.append(t)

    for t in texts:
        if t == "@REFERENCES":
            doc.add_heading("References", level=2)
            for k, n in sorted(order.items(), key=lambda kv: kv[1]):
                if k not in bib:
                    raise KeyError(f"citation key {k} missing from refs.bib")
                p = doc.add_paragraph()
                p.paragraph_format.left_indent = Cm(0.8)
                p.paragraph_format.first_line_indent = Cm(-0.8)
                p.add_run(f"[{n}] ")
                add_inline(p, fmt_ref(bib[k]), size=Pt(11))
            continue
        lines = t.split("\n")
        i = 0
        while i < len(lines):
            ln = lines[i]
            s = ln.strip()
            if not s or s.startswith("<!--"):
                i += 1
                continue
            if s.startswith("```"):
                j = i + 1
                code = []
                while j < len(lines) and not lines[j].strip().startswith("```"):
                    code.append(lines[j])
                    j += 1
                p = doc.add_paragraph()
                r = p.add_run("\n".join(code))
                r.font.name = "Consolas"
                r.font.size = Pt(8.5)
                p.paragraph_format.line_spacing = 1.0
                i = j + 1
                continue
            if s.startswith("$$"):
                eq = s[2:]
                j = i
                while not eq.rstrip().endswith("$$"):
                    j += 1
                    eq += " " + lines[j].strip()
                eq = eq.rstrip()[:-2]
                p = doc.add_paragraph()
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                add_inline(p, "$" + eq + "$")
                i = j + 1
                continue
            m = re.match(r"\{\{TABLE:(.+?)\}\}", s)
            if m:
                name = m.group(1)
                cap, body = tables[name]
                p = doc.add_paragraph()
                add_inline(p, f"**{name}.** {cap}", size=Pt(10))
                rows = [r for r in body.split("\n") if r.startswith("|")]
                notes = [r for r in body.split("\n") if r and not r.startswith("|")]
                for nline in notes:
                    add_inline(doc.add_paragraph(), nline, size=Pt(10))
                add_table(doc, rows)
                i += 1
                continue
            m = re.match(r"\{\{FIG:(.+?)\|(.+)\}\}", s)
            if m:
                doc.add_picture(f"figures/{m.group(1)}.png", width=Cm(16))
                doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
                p = doc.add_paragraph()
                add_inline(p, m.group(2), size=Pt(10))
                i += 1
                continue
            if s.startswith("|"):
                rows = []
                while i < len(lines) and lines[i].strip().startswith("|"):
                    rows.append(lines[i])
                    i += 1
                add_table(doc, rows)
                continue
            h = re.match(r"(#{1,4}) (.*)", s)
            if h:
                lvl = len(h.group(1))
                if lvl == 1:
                    p = doc.add_paragraph()
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    add_inline(p, h.group(2), True, Pt(16))
                else:
                    hp = doc.add_heading(level=lvl - 1)
                    add_inline(hp, h.group(2))
                i += 1
                continue
            if re.match(r"^(\d+)\. ", s):
                p = doc.add_paragraph(style="List Number")
                add_inline(p, re.sub(r"^\d+\. ", "", s))
                i += 1
                continue
            if s.startswith(("- ", "* ")):
                p = doc.add_paragraph(style="List Bullet")
                add_inline(p, s[2:])
                i += 1
                continue
            # paragraph: join wrapped lines
            buf = [s]
            while i + 1 < len(lines) and lines[i + 1].strip() and not re.match(
                    r"^(#|\||```|\$\$|\{\{|- |\* |\d+\. )", lines[i + 1].strip()):
                i += 1
                buf.append(lines[i].strip())
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            add_inline(p, " ".join(buf))
            i += 1
    doc.save(OUT)
    print(f"wrote {OUT}; {len(order)} references cited")
    unused = sorted(set(bib) - set(order))
    if unused:
        print("bib entries not cited:", unused)


if __name__ == "__main__":
    main()
