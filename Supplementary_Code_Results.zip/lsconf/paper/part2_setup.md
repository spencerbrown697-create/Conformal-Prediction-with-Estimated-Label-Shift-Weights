## 5. Experimental setup

### 5.1 Datasets

We use five public classification benchmarks (Table 2). All are tabular or low-resolution image data, which keeps the study within reach of a laptop CPU while still covering 6 to 26 classes and both balanced and strongly imbalanced label distributions. Digits ships with scikit-learn [@pedregosa2011sklearn]. Pendigits, satimage and letter [@frey1991letter] are downloaded from OpenML [@vanschoren2014openml], and Covertype [@blackard1999covertype] through scikit-learn's official fetcher. For Covertype we take one fixed stratified subsample of 30,000 points (random seed 0) to keep run times short. The subsample keeps the natural imbalance of the full dataset, in which the smallest class makes up about 0.5% of the data. Features are standardised inside the model pipeline using statistics from the training split only. None of the datasets contains personal information.

**Table 2.** Datasets used in the experiments. "Min/max class share" is the smallest and largest class proportion in the data used.

| Dataset | Source (identifier) | Instances | Features | Classes | Min / max class share |
|---|---|---|---|---|---|
| digits | scikit-learn `load_digits` (UCI optdigits subset) | 1,797 | 64 | 10 | 0.097 / 0.102 |
| pendigits | OpenML data_id 32 | 10,992 | 16 | 10 | 0.096 / 0.104 |
| satimage | OpenML data_id 182 | 6,430 | 36 | 6 | 0.097 / 0.238 |
| letter | OpenML data_id 6 [@frey1991letter] | 20,000 | 16 | 26 | 0.037 / 0.041 |
| covtype | scikit-learn `fetch_covtype` [@blackard1999covertype], stratified subsample | 30,000 | 54 | 7 | 0.005 / 0.488 |
| covtype (full, natural shift) | same source, all records; split by wilderness area | 581,012 | 50 | 7 | 0.005 / 0.488 |

Download links: https://archive.ics.uci.edu/dataset/80 (optical digits); https://www.openml.org/d/32; https://www.openml.org/d/182; https://www.openml.org/d/6; https://archive.ics.uci.edu/dataset/31 (Covertype).

### 5.2 Data splits and label-shift simulation

For each random seed $s\in\{0,\dots,29\}$, each dataset is split, stratified by class, into four disjoint parts: *train* (50%) for fitting the classifier, *est* (10%) as the labelled source data for BBSE, *cal* (20%) as the conformal calibration set, and *pool* (20%) from which target data are drawn. The split seed is $1000s$.

Label shift is simulated as in [@lipton2018bbse]. Target class proportions are drawn as $q\sim\mathrm{Dirichlet}(c\cdot\mathbf 1_K)$ with concentration $c\in\{10,1,0.1\}$; a smaller $c$ gives a more extreme shift. We also include a "no shift" condition with $q=\pi$. Because the Dirichlet is centred on the uniform distribution, even $c=10$ is a sizeable shift for the imbalanced Covertype data. For each seed and shift level we take 10 independent draws of $q$. For each draw, an unlabelled target sample of $m=500$ points and a separate labelled evaluation sample of 2,000 points are generated: class counts are drawn from $\mathrm{Multinomial}(\cdot, q)$, and points are then drawn with replacement from the pool members of each class. Since the pool is disjoint from all other splits, $P(x\mid y)$ is the same in the source and target data by construction. The random generator for each draw is seeded with the triple (seed, shift index, draw index).

**Natural shift.** Each Covertype record belongs to one of four wilderness areas of the Roosevelt National Forest (Rawah, Neota, Comanche Peak and Cache la Poudre), and the cover-type proportions differ sharply between areas. For example, lodgepole pine (class 2) makes up 56% of Rawah but 8% of Cache la Poudre, where ponderosa pine (class 3) makes up 58%. We hold out one area as the target domain and use the other three as the source. Cache la Poudre is never held out, because it contains every example of class 4 (cottonwood/willow); as a target it would introduce a class unseen in the source, which no label-shift method can handle. For each target area and seed $s\in\{0,\dots,9\}$, we take a stratified source subsample of 60,000 records and split it into train/est/cal parts as above, drop the four area-indicator features, and draw 10 times an unlabelled target sample of 500 records and a disjoint labelled evaluation sample of 2,000 records, without replacement, from the held-out area. The oracle weights are the class proportions of the whole held-out area divided by the source proportions. Nothing in this design makes $P(x\mid y)$ equal across areas. Within lodgepole pine alone, for example, the mean elevation ranges from 2,472 m in Cache la Poudre to 3,214 m in Neota. This experiment therefore tests the methods outside the conditions of their guarantees.

### 5.3 Classifier and scores

The main black-box model is multinomial logistic regression (scikit-learn `LogisticRegression`, L2 penalty, $C=1$, L-BFGS, max 3,000 iterations) after standardisation. We chose logistic regression on purpose. In a pilot run, histogram gradient boosting reached 96–97% accuracy on digits and letter, and at that accuracy almost all score distributions are concentrated near zero and every method gives nearly the same sets. With a weaker model the per-class score distributions differ more, and that is when label shift actually matters for conformal prediction. Gradient boosting (scikit-learn `HistGradientBoostingClassifier`, 200 iterations, learning rate 0.1, no early stopping; [@ke2017lightgbm]) is kept as an ablation. The main score is LAC; the randomised APS score is an ablation. The miscoverage level is $\alpha=0.1$.

### 5.4 Methods compared

1. **SCP** — standard split conformal prediction, which ignores the shift.
2. **Mondrian** — class-conditional conformal prediction.
3. **WCP-oracle** — weighted CP with the true weights $w=q/\pi$ (not available in practice; included as a reference).
4. **WCP-BBSE** and **WCP-MLLS** — weighted CP with BBSE or MLLS weights.
5. **WCP-BBSE-S** and **WCP-MLLS-S** — the same with bootstrap shrinkage ($B=100$).
6. **WCP-BBSE-BC** and **WCP-MLLS-BC** — bound-corrected weighted CP with Mondrian fallback (Section 3.7; $\delta=0.1$, $B=100$, fallback when $t>\alpha/2$). The bootstrap replicates are shared with the shrinkage step, so BC adds no extra resampling.

In the fixed-shrinkage ablation, we also run WCP-BBSE with fixed $\kappa\in\{0,0.25,0.5,0.75,1\}$. Here $\kappa=0$ is SCP and $\kappa=1$ is plain WCP-BBSE.

### 5.5 Metrics and statistical analysis

For each draw we record: (i) **coverage** on the 2,000 evaluation points; (ii) **mean set size**; (iii) **worst-class coverage**, the minimum class-conditional coverage over classes with at least 20 evaluation points; (iv) the **TV weight error** $\tfrac12\sum_y\pi_y|\hat w_y-w_y|$ from Proposition 3; and (v) **under-coverage**, an indicator that coverage fell below $1-\alpha-0.02 = 0.88$. The tolerance of 0.02 is about three standard errors of a coverage estimate based on 2,000 points, so a draw is flagged only when the shortfall is clearly beyond sampling noise.

The statistical unit is the seed. For each seed we average over the 10 draws, which gives 30 paired values per method in the main experiment. We report mean ± standard deviation over seeds. Paired comparisons use the two-sided Wilcoxon signed-rank test [@wilcoxon1945individual] together with a percentile bootstrap 95% confidence interval for the mean paired difference (10,000 resamples). Within each metric, *p*-values are adjusted across all datasets, shift levels and comparisons with Holm's method [@holm1979simple], following the advice of Demšar [@demsar2006statistical] to use non-parametric paired tests when comparing methods. Each family contains every dataset, shift level and comparison for one metric. As effect sizes we report the paired mean difference with its bootstrap confidence interval, the matched-pairs rank-biserial correlation $r_{rb}\in[-1,1]$ (the difference between the proportions of favourable and unfavourable rank sums; $\pm1$ when all seeds agree in sign) and Cohen's $d_z$ (mean difference divided by the standard deviation of the differences). An earlier version of this study used 10 seeds. With 10 seeds the smallest attainable two-sided Wilcoxon *p*-value is 0.002, and after Holm correction no comparison could reach significance, so the main experiment was extended to 30 seeds. The ablations and the natural-shift experiment use 5 and 10 seeds respectively and are reported descriptively, without significance tests.

### 5.6 Implementation and hardware

All code is written in Python 3.11.7 with NumPy 2.4.6, SciPy 1.17.1, pandas 3.0.6, scikit-learn 1.9.1 and matplotlib 3.11.2. Experiments were run on a laptop with an Intel Core i3-6006U CPU (2 cores, 4 threads, 2.0 GHz), 4 GB RAM and Windows 10 Pro (build 19045), without a GPU. On this machine each block of ten seeds of the main experiment took about 50 minutes, the natural-shift experiment about 10 minutes, and the ablations about 2 hours in total (from the run logs). Code, seeds and raw per-draw CSV files are provided in the supplementary repository (Section "Data availability").
