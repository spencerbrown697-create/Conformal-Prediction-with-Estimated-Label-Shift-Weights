# Submission package: Shrinking Estimated Label-Shift Weights for Conformal Prediction

*Companion document to the manuscript. Items in [SQUARE BRACKETS] must be completed by the authors before submission.*

## 0. Note on journal requirements (please read first)

The official *Artificial Intelligence* Guide for Authors on ScienceDirect could not be opened when this package was prepared (HTTP 403, 10 October 2026). The following points were confirmed from the journal's editorial web page (https://aij.ijcai.org/?p=459, accessed 10 October 2026): submissions go through Editorial Manager; the journal wants "mature high quality work that is complete and novel"; articles have no page limit, but reviewers suggest about 20–30 single-column pages; Research Notes are limited to 4,500 words; and papers with poor English may be returned without review. The generative-AI disclosure rules were taken from Elsevier's policy page (accessed the same day). Highlights (3–5 bullets, ≤ 85 characters), the abstract length and the keyword count follow general Elsevier practice and **must be checked against the current Guide for Authors** before submission.

**Honest fit assessment.** *Artificial Intelligence* is highly selective and favours significant methodological or theoretical advances. After revision, the paper offers a label-shift form of a known bound, a new bound-corrected procedure built on it (with a coverage guarantee, Proposition 5), a shrinkage rule, and a careful CPU-scale empirical study that now includes a natural-shift experiment on 581,012 records. The theoretical contribution remains modest. A desk rejection on grounds of significance is a real possibility. If that happens, journals whose scope fits this work closely include *International Journal of Approximate Reasoning*, *Machine Learning*, *Pattern Recognition*, *Neural Networks* and *Knowledge-Based Systems*. Check each journal's current scope before choosing.

## 1. Scope-fit paragraph for the editor

The manuscript addresses reliable uncertainty quantification for classifiers whose deployment environment differs from the training environment, a central concern of trustworthy and open-environment AI. It connects a learning-theoretic result (a coverage bound for conformal prediction with estimated label-shift weights) to a new procedure that turns the bound into a decision rule, and tests both under simulated and natural shift in a fully reproducible study with released code, seeds and raw results. It also states precisely where the guarantees stop: in one natural-shift dataset, where the label-shift assumption is violated, every method studied falls short of its target. The paper is aimed at the journal's machine learning readership and makes no claims beyond what its experiments support. Its negative findings (when weighting and shrinkage do *not* help) are reported alongside the positive ones, which we believe makes it useful to researchers and practitioners alike.

## 2. Cover letter

*Editors-in-Chief as listed on the AIJ organisation page (https://aij.ijcai.org/?p=802, page dated 2 March 2022, accessed 10 October 2026). Confirm on the current Elsevier masthead before sending; replace the names if the editors have changed.*

[INSERT DATE OF SUBMISSION]

Professor Sylvie Thiébaux and Professor Michael Wooldridge
Editors-in-Chief, *Artificial Intelligence*

Dear Professor Thiébaux and Professor Wooldridge,

We submit the manuscript "Conformal Prediction with Estimated Label-Shift Weights: A Coverage Bound, Bound-Corrected Weighting, and Evidence from Simulated and Natural Shift" for consideration as a full research article in *Artificial Intelligence*.

Conformal prediction gives distribution-free coverage guarantees, but these break when class frequencies change between training and deployment. Reweighting the calibration data restores the guarantee only if the class weights are known; in practice they are estimated, often from a few hundred unlabelled examples. Our manuscript shows that the resulting coverage loss is bounded by the total-variation error of the weights. It then turns this bound into a new procedure, bound-corrected weighted conformal prediction, which estimates the weight error by bootstrap, tightens the miscoverage level accordingly, and falls back to class-conditional prediction when the weights are too uncertain. We prove an exact coverage inequality for it, state clearly that its nominal guarantee is approximate because the bootstrap error estimate is not a guaranteed bound, and measure the resulting gap. We test it, together with a shrinkage rule and standard baselines, on five benchmarks with controlled shift (30 seeds) and on a natural shift between forest areas in the full Covertype data.

The results are reported in full, including where the methods do not help. Under pure label shift the corrections work as intended. In our natural-shift dataset, however, no method, not even weighting with the true class proportions, reaches its target, because the areas differ in more than their class mix; we do not generalise from this single dataset. We state this limit of scope explicitly and believe it will be useful to the journal's readers working on reliable AI.

All code, random seeds and raw results are released, and every number in the paper can be regenerated on a laptop CPU in about three hours. The manuscript is original, has not been published elsewhere and is not under consideration by another journal. All authors have approved the submission and declare no competing interests. Generative-AI assistance used during preparation is disclosed in the manuscript, as Elsevier policy requires.

Thank you for considering our work.

Yours sincerely,

Spencer Brown, on behalf of all authors (Spencer Brown, Chen Zhang, Wu Huang, Xie Song)
College of Artificial Intelligence, Tsinghua University, Beijing 100084, China
spencerbrown697@gmail.com

*(about 350 words)*

## 3. Suggested reviewers

The names below are researchers who authored work cited in the manuscript and who work directly on conformal prediction or label shift. **Affiliations are given as they appeared at the time of the cited publication and must be checked on each person's current web page. Find official email addresses yourself; do not guess them.** Before suggesting anyone, confirm that none of the authors has co-authored with them in the last five years, shares an institution with them, or has another conflict of interest. Editors often prefer active mid-career researchers to very senior ones, so you may wish to swap in co-authors of the cited papers.

| # | Name | Affiliation (verify) | Why suitable | Email |
|---|---|---|---|---|
| 1 | Aaditya Ramdas | Carnegie Mellon University, USA | Co-author of the label-shift conformal method we build on (Podkopaev and Ramdas, UAI 2021) and of weighted conformal prediction | [email@example.edu] |
| 2 | Zachary C. Lipton | Carnegie Mellon University, USA | Proposed BBSE and analysed label-shift estimation (Lipton et al., ICML 2018; Garg et al., NeurIPS 2020) | [email@example.edu] |
| 3 | Anastasios N. Angelopoulos | University of California, Berkeley, USA (at time of cited work) | Conformal prediction for classification (RAPS) and class-conditional conformal prediction | [email@example.edu] |
| 4 | Matteo Sesia | University of Southern California, USA | Adaptive prediction sets (APS) for classification (Romano, Sesia and Candès, NeurIPS 2020) | [email@example.edu] |
| 5 | Peng Zhao | Nanjing University, China | Label shift under non-stationarity with provable guarantees (Bai et al., NeurIPS 2022) | [email@example.edu.cn] |
| 6 | Hongxin Wei | Southern University of Science and Technology, China | Conformal prediction for deep classifiers (Huang et al., ICML 2024) | [email@example.edu.cn] |

## 4. Pre-submission checklist to reduce desk-rejection risk

**Scope fit (one paragraph to adapt for the submission form).** See Section 1 above.

**Novelty, stated precisely and without overclaiming:**
- A label-shift statement of the estimated-weight coverage bound, with the weight error measured as π-weighted TV (Proposition 3); attributed to the general results it specialises.
- **New method:** bound-corrected weighted CP with a Mondrian fallback, with a coverage guarantee (Proposition 5).
- A bootstrap, tuning-free shrinkage rule for label-shift weights, motivated by an explicit MSE argument (Proposition 4).
- A head-to-head comparison of SCP, Mondrian CP and weighted CP (oracle, BBSE and MLLS weights; shrunk; bound-corrected) across shift severities and unlabelled sample sizes.
- A natural-shift test on 581,012 Covertype records that marks the limit of the label-shift guarantees.
- A documented case of numerical fragility in BBSE with practical consequences for reproducibility.

| ☐ | Check | Status |
|---|---|---|
| ☐ | Title, abstract and highlights claim no more than the results show | Done in draft; re-read after final edits |
| ☐ | Every number in the text matches the generated tables | Run `python scripts/make_tables.py` and compare |
| ☐ | Mean ± std over seeds, CIs and adjusted *p*-values reported | Tables 3–8, A1–A2 |
| ☐ | The limits of the significance tests are stated openly | Section 6.4 |
| ☐ | Post-hoc analyses labelled as post hoc | Table 7 |
| ☐ | Ablations cover the key design choices | Section 7 (m, κ, score, model, α) |
| ☐ | Limitations section is complete and honest | Section 8.4 |
| ☐ | Code, data loaders, seeds and raw results archived with a DOI | [Zenodo DOI] |
| ☐ | AI-use declaration present and accurate | Declarations section |
| ☐ | No identifying data; ethics statement included | Not applicable (public data) |
| ☐ | References verified (42 of 42 resolved on 11 Oct 2026; one unregistered DOI removed) | Re-run `paper/verify_refs.py` after edits |
| ☐ | Professional English check | Recommended before submission |
| ☐ | All `[INSERT …]` placeholders filled | Search the files |

## 5. Response-to-reviewers template

**Opening letter (adapt):**

> Dear Editor and Reviewers,
>
> Thank you for the careful reading of our manuscript and for the constructive comments. We have revised the paper accordingly. Below we reply to each comment point by point. Reviewer comments are in italics, our responses follow, and changes in the manuscript are marked in blue in the revised version, with page and line numbers given for each change. [Summarise the 2–4 most important changes here.]

**Format for each point:**

> **Reviewer X, Comment Y.** *[quote the comment]*
> **Response.** [Agree / partly agree / respectfully disagree, with the reason.]
> **Change in manuscript.** [Section, page, lines; new table or figure number.]

### 5.1 Prepared answers to the ten most likely questions

**Q1. The theoretical result is a corollary of Lei and Candès (2021) and Barber et al. (2023). What is new?**
We agree, and the manuscript says so where Proposition 3 is stated. The main new contribution is not the bound itself but what we build on it: (i) bound-corrected weighted CP, which estimates the π-weighted TV error by bootstrap, tightens α by that amount and falls back to Mondrian CP when the error budget would be exceeded, with the guarantee of Proposition 5; (ii) the shrinkage rule of Proposition 4; and (iii) an empirical check of how tight the bound is (conservative by roughly an order of magnitude). We would be happy to move Proposition 3 to a remark if the reviewer prefers.

**Q2. Why no deep networks or larger image benchmarks?**
All experiments had to run on a laptop CPU, and we preferred real, fully reproducible results to simulated ones. The method itself only needs predicted probabilities, so it applies directly to deep models. We list a CIFAR-10 / ResNet experiment as the first follow-up (Section 6 of this package). If the editor considers it necessary, we will run it on [INSERT available GPU resource] and add it.

**Q3. Missing baselines: RLLS, BCTS-calibrated MLLS, PAC prediction sets, clustered CP.**
We agree that these are relevant and say so in the limitations. RLLS and BCTS-MLLS fit easily into `lsconf/weights.py`, and PAC sets need about a day of implementation. Planned additions are listed in Section 6 of this package.

**Q4. Are the statistical conclusions supported?**
The main experiment now uses 30 seeds (it used 10 in an earlier version, when no test could survive Holm correction). Every comparison reports the mean difference with a bootstrap 95% CI, the rank-biserial correlation, Cohen's $d_z$ and raw and Holm-adjusted *p*-values, with explicitly defined test families (Section 6.4, Table A4). The main effects have $|r_{rb}|\ge0.9$ and survive correction. We also point out that some significant differences are too small to matter. The ablations (5 seeds) and the natural-shift experiment (10 seeds) are reported descriptively.

**Q5. Shrinkage sometimes makes things worse. Why propose it?**
We agree that it is not uniformly beneficial, and the paper says so, including the clearest negative case (BBSE with gradient boosting on Covertype under Dir(1): coverage 0.898 → 0.854; Section 7.4). The benefit is large and consistent when there is little or no shift, which is exactly when practitioners are least sure whether to reweight at all. With calibrated MLLS weights, the cost under real shift was at most a few thousandths of coverage. Section 8.1 therefore recommends shrinkage mainly when the presence of shift is uncertain, and unshrunk weights when a strong shift is evident. A natural improvement, which we would be glad to add, is to shrink only when a shift test does not reject.

**Q6. The bound is loose. What is its practical value?**
It is a worst case over all score functions, so looseness is expected. Its value is in design (it shows that π-weighted L1 error is what matters) and as the basis of the bound-corrected procedure (Section 3.7, Proposition 5), which is evaluated in Sections 6 and 7.

**Q7. The shift is simulated. Real shifts are not pure label shift.**
We agree, and the revised manuscript now includes a natural-shift experiment (Section 6.6): the model is trained on three wilderness areas of the full Covertype data (581,012 records) and deployed on the fourth. No method reaches the 0.90 target there (coverage 0.70–0.83), not even weighting with the true class proportions, because within-class feature distributions differ between areas. We present this as a clear statement of the scope of label-shift corrections (Introduction, "Scope of the claims").

**Q8. Mondrian CP was better on Covertype. Why use weighting at all?**
This is one of our findings, not a weakness of the paper. Weighting pays off when classes are similar and per-class calibration data are scarce (letter: up to 0.40 fewer labels per set at the same coverage); Mondrian CP is preferable when classes are heterogeneous. Section 8.1 turns this into a practical rule.

**Q9. κ̂ is data-dependent. Is there a guarantee?**
Proposition 3 holds for any weights independent of the calibration and test data, which includes the shrunk weights. What we do not have is a guarantee that shrinkage *reduces* the error for a biased estimator with a data-dependent κ̂. We state this as a limitation and see a finite-sample analysis as future work.

**Q10. Logistic regression was chosen after a pilot with gradient boosting. Is this a researcher degree of freedom?**
Yes, and we report it openly in Section 5.3. The choice was made before the main experiments, for the stated reason that with a near-perfect classifier all methods coincide. The gradient-boosting results are reported in full as an ablation (Section 7.4), so readers can see both regimes.

## 6. Prioritised follow-up experiments if reviewers ask for more

| Priority | Experiment | How | Expected cost | Expected effect on acceptance |
|---|---|---|---|---|
| 1 | Deep-model benchmark: CIFAR-10 (and CIFAR-100) with a pretrained ResNet-18, Dirichlet label shift | Save softmax outputs once on a GPU, then reuse `run_experiments.py` on stored probabilities | ~3–5 GPU-hours plus ~2 CPU-hours | High: answers the most likely scale objection |
| 2 | Extra baselines: RLLS, BCTS-calibrated MLLS, PAC sets, clustered CP | Add estimators to `weights.py` and predictors to `conformal.py` | 2–4 days of coding; < 3 CPU-hours | High: answers the most likely comparison objection |
| 3 | A second natural-shift benchmark with images, e.g. WILDS iWildCam (species proportions change across camera traps) or a DomainBed dataset | Extract features with a pretrained network on a GPU, then reuse `run_natural_shift.py` logic | ~1 day plus GPU feature extraction | Medium–high: extends the scope result beyond tabular data |
| 4 | 30 seeds per setting for adequately powered tests | Same scripts, `--seeds 30` | ~3 CPU-hours for the main run | Medium: fixes the significance limitation |
| 5 | Sensitivity of bound-corrected WCP to δ (0.05, 0.1, 0.2) and to the fallback threshold (α/4, α/2, α) | Flag `--bc-delta`; one-line change for the threshold | < 2 CPU-hours | Medium: shows the method is not tuned to the data |
| 6 | Sensitivity to bootstrap size B (50, 100, 500) and to the labelled split size for BBSE | Flags `--boot` and split fractions | < 2 CPU-hours | Low–medium: robustness check |
| 7 | Class-conditional coverage of weighted methods under shift | Already logged per class; add a table | < 1 hour | Low: completes the picture |

## 7. Docx export instructions and final assembly checklist

See Sections 8–9 below (shared with the manuscript repository's `paper/part6_export_checklist.md`).
