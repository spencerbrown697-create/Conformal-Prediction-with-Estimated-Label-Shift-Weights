# Conformal Prediction with Estimated Label-Shift Weights: A Coverage Bound, Bound-Corrected Weighting, and Evidence from Simulated and Natural Shift

## Title page

**Title:** Conformal Prediction with Estimated Label-Shift Weights: A Coverage Bound, Bound-Corrected Weighting, and Evidence from Simulated and Natural Shift

**Short title / running head:** Label-shift conformal prediction with estimated weights

**Authors:** Spencer Brown^a,*^, Chen Zhang^a^, Wu Huang^a^, Xie Song^a^

^a^ College of Artificial Intelligence, Tsinghua University, Beijing 100084, China

\* Corresponding author: Spencer Brown. E-mail address: spencerbrown697@gmail.com

## Highlights

1. Coverage lost to label-shift weight error is bounded by its total-variation distance.
2. New method: tighten alpha by the weight error, or fall back to Mondrian if too noisy.
3. Bound correction never under-covered more often than Mondrian in 20 shift settings.
4. In one natural-shift dataset every method under-covered, even the true-weight oracle.
5. Code, seeds and raw results are released to regenerate every table and figure.

## Abstract

**Background:** Conformal prediction gives classifiers distribution-free coverage guarantees, but these fail when class proportions change between training and deployment (label shift). Reweighting the calibration data restores validity only if the class weights are known; in practice they must be estimated.
**Methods:** We prove that the coverage lost to estimated weights is bounded by their total-variation error. Building on this, bound-corrected weighted conformal prediction tightens the miscoverage level by a bootstrap estimate of the weight error and falls back to class-conditional (Mondrian) prediction when the weights are too uncertain. We also propose a shrinkage rule. Methods were compared on five benchmarks under Dirichlet label shift (30 seeds, five ablations) and under natural geographic shift in the full Covertype data.
**Results:** Under simulated shift, split conformal coverage fell to 0.707 against a 0.90 target, while Mondrian prediction averaged at least 0.90 in all 20 settings. Bound correction never under-covered more often than Mondrian prediction. Its bootstrap error estimate fell below the true weight error in 8–39% of draws, yet the resulting coverage excess averaged at most 0.003. With 500 unlabelled points it rarely gave smaller sets than Mondrian prediction. Shrinkage cut the no-shift weight error by 0.059–0.085. In one natural-shift dataset, where the label-shift assumption is violated, every method, including weighting with the true class proportions, covered only 0.70–0.83.
**Conclusions:** Bound correction offers a cautious, approximately guarantee-preserving way to use estimated weights, but all label-shift corrections depend on an assumption that should be checked.
**Significance:** The study clarifies when label-shift corrections for conformal prediction can be trusted.

## Keywords

Conformal prediction; Label shift; Distribution shift; Importance weighting; Uncertainty quantification; Shrinkage estimation; Prediction sets

## 1. Introduction

Machine learning models are usually trained on one data set and used on another. A common difference between the two is the mix of classes. A disease that is rare in the hospital where a model was trained may be frequent in another region; a land-cover classifier trained in one season meets a different proportion of cover types in the next. When the class-conditional distribution of the inputs stays the same and only the class proportions move, the change is called label shift, prior probability shift or target shift [@saerens2002adjusting; @zhang2013domain; @morenotorres2012unifying]. It is one of the standard forms of dataset shift [@quinonero2009dataset], and it is also one of the "open environment" conditions that recent work has argued machine learning systems must handle routinely rather than as an exception [@zhou2022open].

For many applications a point prediction is not enough. A user also wants to know how uncertain the model is, preferably in a form that comes with a guarantee. Conformal prediction gives such a guarantee with very few assumptions [@vovk2022alrw; @shafer2008tutorial; @angelopoulos2023gentle]. In split (inductive) conformal prediction [@papadopoulos2002icm; @lei2018distribution], a held-out calibration set is used to choose a threshold on a non-conformity score, and the resulting prediction set contains the true label with probability at least $1-\alpha$. The guarantee needs only one thing: calibration and test points must be exchangeable. Label shift breaks exactly this assumption. If a class with poorly calibrated scores becomes more common at test time, the marginal coverage of standard split conformal prediction can fall well below the nominal level, and the drop is largest for the classes that matter most.

There are two established ways around this. The first is class-conditional, or Mondrian, conformal prediction [@vovk2013conditional; @sadinle2019least], which calibrates a separate threshold for each class. Its coverage holds within every class, so it also holds for any mixture of classes, and label shift therefore cannot break it. The price is efficiency: each class gets only a fraction of the calibration data, and rare classes get large thresholds and large prediction sets [@ding2023classconditional]. The second is weighted conformal prediction [@tibshirani2019covariate], which reweights the calibration scores by the likelihood ratio between the test and calibration distributions. Under label shift this ratio depends only on the label, $w_y = q_y/\pi_y$, where $\pi$ and $q$ are the source and target class proportions [@podkopaev2021labelshift]. With the true weights, weighted conformal prediction keeps marginal coverage and usually gives smaller sets than the Mondrian approach, because all calibration points are pooled.

The difficulty is that the true weights are never known. They must be estimated from unlabelled target data, typically with black-box shift estimation (BBSE) [@lipton2018bbse] or with maximum-likelihood label shift estimation (MLLS) via the EM algorithm [@saerens2002adjusting; @alexandari2020mlls; @garg2020unified]. Both estimators can be noisy. BBSE inverts a confusion matrix, which becomes ill-conditioned when some classes are rare or often confused. MLLS depends on the calibration of the predicted probabilities [@guo2017calibration; @alexandari2020mlls]. A natural question follows, and it is the subject of this paper: how much coverage do we actually lose when estimated weights replace the true ones, and can we reduce that loss cheaply, without labelled target data?

Our starting point is a simple observation. Under label shift, the target distribution and the distribution implied by estimated weights differ only in their label marginals. The coverage loss of weighted conformal prediction can therefore be bounded by the total variation (TV) distance between these two label distributions, $\tfrac12\sum_y \pi_y|\hat w_y - w_y|$. This is a special case of known results for weighted conformal prediction with estimated weights [@lei2021counterfactuals; @barber2023beyond], but stated for label shift it is very concrete: every unit of weight error, weighted by the source class proportions, can cost at most half a unit of coverage. The bound suggests two remedies, and we study both. The first is to make the weights more accurate. When there is little or no shift, the estimated weights are mostly noise, and pulling them back towards 1 (the "no shift" weights) should help; when the shift is large, the estimate carries real signal and should be left alone. We implement this with a positive-part James–Stein style rule [@james1961estimation] in which a nonparametric bootstrap [@efron1994bootstrap] estimates the variance of the weight estimator and sets the amount of shrinkage. The second remedy, which is the main methodological proposal of this paper, is to accept the error and pay for it. The same bootstrap gives an estimate $t$ of the weight error, and running weighted conformal prediction at the stricter level $\alpha-t$ restores the guarantee of the bound. When $t$ uses up more than half of the error budget, the weights are too uncertain to be worth using, and the procedure falls back to Mondrian conformal prediction, which needs no weights at all. We call this *bound-corrected* weighted conformal prediction (WCP-BC).

Shrinkage of label-shift weights is not new in itself. Regularised learning under label shift (RLLS) [@azizzadenesheli2019rlls] regularises the weight estimator to account for its uncertainty in the small-sample regime. PAC prediction sets under label shift [@si2024pac] take a different route: they propagate confidence intervals for the weights through the conformal threshold, which gives a stronger (PAC) guarantee at the cost of more conservative sets. Our goal is narrower. We want a rule that needs no tuning, fits in a few lines of code, works with either BBSE or MLLS, and can be checked against the TV bound in experiments.

The contributions of this paper are as follows.

1. **A coverage bound in label-shift form.** We prove a non-asymptotic bound: the coverage loss of label-shift weighted conformal prediction with estimated weights is at most the π-weighted TV error of the weights (Proposition 3). This complements the asymptotic validity result of Podkopaev and Ramdas [@podkopaev2021labelshift].
2. **Bound-corrected weighted conformal prediction (new method).** We turn the bound into a procedure that estimates the weight error by bootstrap, tightens the miscoverage level by that amount, and falls back to Mondrian prediction when the weights are too uncertain. Proposition 5 gives an exact coverage inequality whose excess term is the part of the weight error not covered by the error estimate. Because the bootstrap estimate is not a guaranteed upper bound, the nominal level is only approximate; we measure the excess empirically.
3. **A tuning-free shrinkage rule.** We derive the shrinkage factor that minimises the mean squared weight error under a simple noise model (Proposition 4), and turn it into a bootstrap rule that can be applied on top of BBSE or MLLS.
4. **Controlled experiments.** On five public benchmarks (digits, pendigits, satimage, letter and Covertype), with four levels of Dirichlet label shift, thirty random seeds and ten shift draws per seed, we compare split, Mondrian, oracle-weighted, estimated-weight, shrunk and bound-corrected conformal prediction, using paired Wilcoxon signed-rank tests with Holm correction and bootstrap confidence intervals. Ablations cover the unlabelled sample size, fixed versus adaptive shrinkage, the score function, the base model and the miscoverage level.
5. **A natural-shift test.** On the full Covertype data (581,012 cells), we train on three wilderness areas and deploy on the fourth, so the class proportions change for real rather than by resampling. This shows what the methods do when the label-shift assumption is only approximately true.
6. **Full reproducibility.** We release all code, seeds and raw per-run results; every number in the paper can be regenerated on a two-core laptop CPU in about three hours.

The weighted procedure we build on is the one of Tibshirani et al. [@tibshirani2019covariate] and Podkopaev and Ramdas [@podkopaev2021labelshift]. What is new here is the bound-corrected procedure with its fallback, the shrinkage rule, and the evidence about when each of them, and the plain Mondrian baseline, should be preferred.

**Scope of the claims.** Our conclusions apply to *label shift*: the class proportions change while the class-conditional input distribution stays the same. This is how the shift is constructed in the controlled experiments, so the guarantees of Section 4 hold there by design. They do not extend to covariate or concept shift, and our single natural-shift experiment illustrates this. In that dataset, where the forest areas differ in more than their class mix, every method we tested, including Mondrian prediction and weighted prediction with the true class proportions, covered only 0.70–0.83 of the target labels against a 0.90 target (Section 6.6). Our evidence also comes from tabular and small-image data with logistic-regression and gradient-boosting classifiers, unlabelled target samples of 100–3,000 points, and marginal (not class-conditional) coverage targets. We make no claims outside these conditions.

The rest of the paper is organised as follows. Section 2 reviews related work. Section 3 sets up the problem and describes the methods. Section 4 gives the theoretical results. Section 5 describes the experimental protocol, Section 6 reports the main results (with the natural-shift experiment in Section 6.6), and Section 7 the ablations. Section 8 discusses limitations and practical advice, and Section 9 concludes.

## 2. Related work

**Conformal prediction for classification.** Conformal prediction was developed by Vovk, Gammerman and Shafer [@vovk2022alrw]; tutorials and reviews are given in [@shafer2008tutorial; @angelopoulos2023gentle; @fontana2023conformal]. Split conformal prediction [@papadopoulos2002icm; @lei2018distribution] avoids refitting the model and is the version used in almost all recent work. For classification, the choice of non-conformity score matters a great deal. The least ambiguous set-valued classifier (LAC) score $1-\hat p(y\mid x)$ gives the smallest average sets when the probabilities are well estimated [@sadinle2019least]. Adaptive prediction sets (APS) [@romano2020classification] and their regularised version RAPS [@angelopoulos2021raps] aim at better conditional coverage. Score functions based on label ranking have also been proposed [@huang2024ranking]. Class-conditional coverage was studied by Vovk [@vovk2013conditional] and by Sadinle et al. [@sadinle2019least]. Ding et al. [@ding2023classconditional] point out that per-class calibration becomes unreliable when there are many classes with few examples each, and propose clustering classes to share calibration data.

**Conformal prediction under distribution shift.** Tibshirani et al. [@tibshirani2019covariate] showed that under covariate shift, exchangeability can be replaced by "weighted exchangeability" if calibration scores are reweighted by the likelihood ratio. Podkopaev and Ramdas [@podkopaev2021labelshift] adapted the idea to label shift, where the ratio depends on the label only. Their guarantee is exact when the weights are known and asymptotic when a consistent estimate (BBSE in their experiments) is plugged in, and they also proposed the label-conditional (Mondrian) approach as an exact alternative under label shift. Lei and Candès [@lei2021counterfactuals] studied weighted conformal inference with estimated weights in causal inference, and Barber et al. [@barber2023beyond] bounded the coverage gap for non-exchangeable data by a weighted sum of TV distances. Other lines of work protect against a whole family of shifts [@cauchois2024robust] or adapt the threshold online when the shift is unknown and changing [@gibbs2021adaptive]. Si et al. [@si2024pac] constructed PAC prediction sets under label shift by carrying confidence intervals for the weights through the calibration step.

**Label shift estimation.** The classical approach is the EM procedure of Saerens et al. [@saerens2002adjusting], which maximises the likelihood of the unlabelled target data over the class priors. Zhang et al. [@zhang2013domain] studied target and conditional shift with kernel mean matching. BBSE [@lipton2018bbse] estimates the weights by solving a linear system built from the confusion matrix of any black-box classifier; RLLS [@azizzadenesheli2019rlls] adds regularisation towards no shift. Alexandari et al. [@alexandari2020mlls] showed that MLLS with bias-corrected calibration is very hard to beat, and Garg et al. [@garg2020unified] explained the relationship between the two families. Detecting shift before correcting it was studied by Rabanser et al. [@rabanser2019failing]. Label shift in streaming data has been addressed in [@wu2021online; @bai2022online], including work from Chinese groups on provable online adaptation [@bai2022online].

**Where this paper sits.** Table 1 summarises how the closest approaches deal with the fact that label-shift weights must be estimated. Relative to Podkopaev and Ramdas [@podkopaev2021labelshift], who combine weighting with a consistency argument, and offer label-conditional prediction as a separate option, our contributions are threefold. First, a finite-sample bound in which the cost of weight error is explicit (Proposition 3). Second, a single procedure that uses this bound to decide, from the estimation data alone, whether to weight at a tightened level or to fall back to label-conditional prediction (Proposition 5). Third, a shrinkage rule for the weights. Relative to the PAC sets of Si et al. [@si2024pac], we target marginal rather than calibration-conditional coverage, and our error estimate is a bootstrap heuristic rather than a propagated confidence interval. Our procedure is simpler and works with any weight estimator, but its nominal guarantee is only approximate (Section 4). RLLS [@azizzadenesheli2019rlls] regularises the weight estimator itself for the small-sample regime and comes with a generalisation bound for weighted training; it does not address the coverage of prediction sets. Our literature search was limited (Section 8.4), and we would not be surprised to learn of closely related results.

**Table 1.** How existing approaches and this paper handle estimated label-shift weights in conformal prediction. "Marginal" means coverage on average over the calibration data; "PAC" means coverage with high probability over the calibration data.

| Approach | Weights used | How weight error is handled | Coverage guarantee |
|---|---|---|---|
| Weighted CP under label shift [@podkopaev2021labelshift] | Known, or estimated (BBSE) | Plug-in | Exact (marginal) with known weights; asymptotic with a consistent estimate |
| Label-conditional / Mondrian CP [@vovk2013conditional; @sadinle2019least; @podkopaev2021labelshift] | None | Not needed | Exact (marginal) under any label shift |
| PAC prediction sets under label shift [@si2024pac] | Estimated (confusion matrix) | Confidence intervals propagated through Gaussian elimination | PAC, under the authors' assumptions |
| RLLS [@azizzadenesheli2019rlls] | Estimated, regularised | Regularisation of the estimator | Generalisation bound for weighted training (not prediction sets) |
| This paper: WCP with shrinkage | Estimated (BBSE or MLLS) | Bootstrap-calibrated shrinkage towards no shift | Proposition 3 (finite-sample, marginal, with explicit error term) |
| This paper: bound-corrected WCP | Estimated (BBSE or MLLS) | Level tightened by a bootstrap error estimate; Mondrian fallback | Proposition 5 (exact inequality); nominal level approximate, evaluated empirically |

## 3. Problem setting and methods

### 3.1 Label shift

Let $X\in\mathcal X$ be the input and $Y\in\{1,\dots,K\}$ the label. The source distribution $P$ generates the training and calibration data, and the target distribution $Q$ generates the test data. Under label shift,

$$Q(x\mid y) = P(x\mid y)\quad\text{for all } y,\qquad \pi_y = P(Y=y),\quad q_y = Q(Y=y).$$

The likelihood ratio is then a function of the label only, $dQ/dP(x,y) = w_y = q_y/\pi_y$, and it satisfies $\sum_y \pi_y w_y = 1$. We assume $\pi_y>0$ for every class.

### 3.2 Split conformal prediction

A classifier $f$ is trained on separate data and outputs probabilities $\hat p(y\mid x)$. A score function $s(x,y)$ measures how unusual label $y$ is for input $x$. In the main experiments we use the LAC score $s(x,y)=1-\hat p(y\mid x)$ [@sadinle2019least]; the APS score [@romano2020classification] is used in an ablation. Given calibration data $(X_i,Y_i)_{i=1}^n$ from $P$ with scores $S_i=s(X_i,Y_i)$, standard split conformal prediction (SCP) returns

$$C_{\mathrm{SCP}}(x) = \{y : s(x,y)\le \hat t\},\qquad \hat t = S_{(\lceil (n+1)(1-\alpha)\rceil)},$$

where $S_{(k)}$ is the $k$-th smallest score (and $\hat t=\infty$ if $k>n$). If the test point comes from $P$, then $P(Y\in C_{\mathrm{SCP}}(X))\ge 1-\alpha$ [@vovk2022alrw; @lei2018distribution].

### 3.3 Mondrian (class-conditional) conformal prediction

Mondrian CP computes one threshold per class from the calibration points of that class, $\hat t_y = $ the $\lceil (n_y+1)(1-\alpha)\rceil$-th smallest score among the $n_y$ calibration points with $Y_i=y$, and returns $C_{\mathrm M}(x)=\{y: s(x,y)\le \hat t_y\}$ [@vovk2013conditional; @sadinle2019least].

### 3.4 Label-shift weighted conformal prediction

Following [@tibshirani2019covariate; @podkopaev2021labelshift], for a candidate label $y$ of a test point $x$, define normalised weights

$$p_i^{(y)} = \frac{w_{Y_i}}{\sum_{j=1}^n w_{Y_j} + w_y},\qquad p_{n+1}^{(y)} = \frac{w_y}{\sum_{j=1}^n w_{Y_j} + w_y},$$

and the threshold

$$\hat t^{(y)} = \text{Quantile}_{1-\alpha}\Big(\sum_{i=1}^n p_i^{(y)}\delta_{S_i} + p_{n+1}^{(y)}\delta_{+\infty}\Big).$$

The weighted CP (WCP) set is $C_w(x)=\{y : s(x,y)\le \hat t^{(y)}\}$. Since $\hat t^{(y)}$ depends on $x$ only through the candidate label, only $K$ thresholds need to be computed, and the cost after sorting the calibration scores is $O(Kn)$ (Appendix C). With equal weights, WCP reduces to SCP.

### 3.5 Estimating the weights

The weights are estimated from (i) a small labelled source set, disjoint from the calibration set, and (ii) an unlabelled target sample of size $m$.

*BBSE* [@lipton2018bbse]. Let $\hat C_{ij} = \hat P(f(X)=i, Y=j)$ be the joint confusion matrix of the hard predictions on the labelled source set, and $\hat\mu_i=\hat Q(f(X)=i)$ the distribution of predictions on the target sample. Under label shift $\mu = Cw$, so we solve $\hat C\hat w = \hat\mu$ by least squares.

*MLLS* [@saerens2002adjusting; @alexandari2020mlls]. Starting from $q^{(0)}=\pi$, the EM iteration is
$$r_{ik} \propto \hat p(k\mid x_i)\,\frac{q_k^{(t)}}{\pi_k},\qquad q_k^{(t+1)} = \frac1m\sum_{i=1}^m r_{ik},$$
run until the largest change is below $10^{-8}$ (at most 500 iterations), after which $\hat w = q/\pi$.

For both estimators we clip negative values to 0 and rescale so that $\sum_y\pi_y\hat w_y = 1$. This ensures that $\hat q=\pi\odot\hat w$ is a valid probability vector.

### 3.6 Bootstrap shrinkage of the weights

Write $\|v\|_\pi^2=\sum_y \pi_y v_y^2$. Given an estimate $\hat w$, we draw $B$ bootstrap replicates $\hat w^{*1},\dots,\hat w^{*B}$ by resampling the data the estimator used: both the labelled source set and the target sample for BBSE, and the target sample for MLLS. We then compute

$$\hat v = \sum_y \pi_y\,\widehat{\mathrm{Var}}_b(\hat w^{*b}_y),\qquad \hat d^2 = \|\hat w - \mathbf 1\|_\pi^2,\qquad \hat\kappa = \max\Big(0,\ 1-\frac{\hat v}{\hat d^2}\Big),$$

and use the shrunk weights

$$\hat w^{\mathrm S} = \mathbf 1 + \hat\kappa\,(\hat w - \mathbf 1).$$

Because $\hat w^{\mathrm S}$ is a convex combination of $\hat w$ and $\mathbf 1$, it stays non-negative and still satisfies $\sum_y\pi_y\hat w^{\mathrm S}_y=1$. When the estimate is dominated by noise ($\hat d^2\le\hat v$), $\hat\kappa=0$ and WCP falls back to SCP. When the shift is large compared with the noise, $\hat\kappa\approx1$ and the estimate is barely changed. We call the resulting methods WCP-BBSE-S and WCP-MLLS-S. Algorithm 1 in Appendix A gives the full procedure. We use $B=100$.

### 3.7 Bound-corrected weighted conformal prediction with a Mondrian fallback

Shrinkage tries to make the weights more accurate. A different idea is to accept that they are inaccurate and *pay for the error explicitly*. Proposition 3 below says that weighted CP with weights $\hat w$ loses at most $\mathrm{TV}(\hat w)=\tfrac12\sum_y\pi_y|\hat w_y-w_y|$ of coverage. If we had a valid upper bound $t$ on this error, running weighted CP at the stricter level $\alpha-t$ would restore the nominal level. The bootstrap replicates computed for shrinkage give a heuristic estimate of such a bound at no extra cost (it is not a guaranteed bound; see Section 4):

$$t = \text{the } (1-\delta)\text{-quantile of } \tfrac12\textstyle\sum_y\pi_y\,|\hat w^{*b}_y-\hat w_y|,\quad b=1,\dots,B.$$

When $t$ is large, however, weighted CP at level $\alpha-t$ produces very large sets, and when $t\ge\alpha$ it produces the trivial set of all labels. Mondrian CP, by contrast, is valid under any label shift without any weights (Proposition 2). We therefore use the rule

$$C^{\mathrm{BC}}(x)=\begin{cases}C_{\hat w}(x)\ \text{at level } \alpha-t, & t\le\alpha/2,\\ C_{\mathrm M}(x)\ \text{at level } \alpha, & t>\alpha/2.\end{cases}$$

Fig. 1 shows the whole pipeline. In words: use the weights only when their estimated error costs at most half of the miscoverage budget; otherwise fall back to the class-conditional method. The decision depends only on the estimation data and the unlabelled target sample, never on the calibration or test points, which is what Proposition 5 below requires. We call the resulting methods WCP-BBSE-BC and WCP-MLLS-BC, and use $\delta=0.1$ and $B=100$ throughout. The threshold $\alpha/2$ is a fixed design choice, not a tuned value; we discuss it in Section 8.4.

{{FIG:fig1_pipeline|**Fig. 1.** Overview of the procedure. The classifier is trained once on source data. Label-shift weights are estimated from a labelled source hold-out and an unlabelled target sample, shrunk towards 1 by an amount set by their bootstrap variance, and used to reweight the conformal calibration scores.}}

## 4. Theoretical analysis

All proofs are given in Appendix B.

**Setting and type of guarantee.** The data are used in four independent parts: training data for the classifier $f$; *estimation data*, consisting of the labelled source split used by BBSE and the unlabelled target sample, from which $\hat w$, $\hat\kappa$ and $t$ are computed; a calibration sample $D=(X_i,Y_i)_{i=1}^n$, i.i.d. from $P$; and a test point $(X,Y)\sim Q$, independent of everything else. Unless stated otherwise, every probability below is taken jointly over the calibration sample and the test point, conditional on the training and estimation data. The results are therefore **marginal** guarantees with respect to the calibration data. They are not calibration-conditional (also called training-conditional or PAC) guarantees [@vovk2013conditional]: for one particular calibration sample the coverage can be lower than $1-\alpha$, and PAC-type guarantees under label shift require a different construction [@si2024pac]. In the experiments each seed fixes one calibration sample, so the per-seed coverage is a calibration-conditional quantity. Its average over seeds estimates the marginal coverage in the propositions, and its spread across seeds and draws (the under-coverage rate of Section 5.5) shows the calibration-conditional variability.

**Proposition 1** (oracle weights; [@tibshirani2019covariate; @podkopaev2021labelshift]). Under label shift with true weights $w$, $Q(Y\in C_w(X))\ge 1-\alpha$.

**Proposition 2** (Mondrian CP under label shift; [@vovk2013conditional; @sadinle2019least; @podkopaev2021labelshift]). Suppose every class has at least one calibration point. Then for every class $y$, $P(Y\in C_{\mathrm M}(X)\mid Y=y)\ge 1-\alpha$. Consequently, for any target distribution $Q$ that differs from $P$ only by label shift, $Q(Y\in C_{\mathrm M}(X))\ge 1-\alpha$.

Proposition 2 is standard. The label-conditional approach was already recommended for label shift by Podkopaev and Ramdas [@podkopaev2021labelshift], and we state it here because the bound-corrected method below uses it as its fallback.

**Proposition 3** (estimated weights). Let $\hat w$ be any non-negative weight vector with $\sum_y\pi_y\hat w_y=1$ that is computed from the estimation data. Then, conditional on $\hat w$,

$$Q\big(Y\in C_{\hat w}(X)\big)\ \ge\ 1-\alpha-\mathrm{TV}(\hat w),\qquad \mathrm{TV}(\hat w)=\tfrac12\sum_{y=1}^K\pi_y\,|\hat w_y-w_y|.$$

The error term is exactly the TV distance between the label distributions $\pi\odot\hat w$ and $\pi\odot w$. Podkopaev and Ramdas [@podkopaev2021labelshift] show that weighted CP with estimated weights is *asymptotically* valid when the weight estimator is consistent. Proposition 3 is a non-asymptotic complement: it holds for any fixed $\hat w$, with an explicit error term. The argument is elementary. Weighted CP with $\hat w$ is exactly valid for the label-shift distribution $\hat Q$ implied by $\hat w$, and coverage under $Q$ can differ from coverage under $\hat Q$ by at most $d_{\mathrm{TV}}(Q,\hat Q)$. Coverage bounds expressed through total-variation distances also appear for non-exchangeable data in Barber et al. [@barber2023beyond], and Lei and Candès [@lei2021counterfactuals] study weighted conformal inference with estimated weights in causal inference. In the label-shift setting the bound has a simple reading: what matters is the weight error on each class, weighted by how often that class occurs in the source data.

**Proposition 4** (optimal shrinkage under a simple noise model). Suppose $\hat w = w+\varepsilon$ with $\mathbb E\varepsilon=0$ and $\mathbb E\|\varepsilon\|_\pi^2=v$, and let $\hat w_\kappa=\mathbf 1+\kappa(\hat w-\mathbf 1)$ for a fixed $\kappa\in[0,1]$. Then

$$\mathbb E\|\hat w_\kappa - w\|_\pi^2 = (1-\kappa)^2\|w-\mathbf 1\|_\pi^2+\kappa^2 v,$$

which is minimised at $\kappa^\star = \|w-\mathbf 1\|_\pi^2/(\|w-\mathbf 1\|_\pi^2+v)$, giving the minimum value $v\|w-\mathbf 1\|_\pi^2/(\|w-\mathbf 1\|_\pi^2+v)\le\min(v,\|w-\mathbf 1\|_\pi^2)$. Moreover, by Jensen's inequality, $\mathbb E\,\mathrm{TV}(\hat w_\kappa)\le\tfrac12\big(\mathbb E\|\hat w_\kappa-w\|_\pi^2\big)^{1/2}$.

Since $\mathbb E\|\hat w-\mathbf 1\|_\pi^2=\|w-\mathbf 1\|_\pi^2+v$, the optimum can be written as $\kappa^\star=1-v/\mathbb E\|\hat w-\mathbf 1\|_\pi^2$. Our rule $\hat\kappa=\max(0,1-\hat v/\hat d^2)$ is the plug-in version, with the bootstrap variance in place of $v$ and the observed distance in place of its expectation, in the same way that the positive-part James–Stein estimator is a plug-in for an oracle shrinkage factor [@james1961estimation]. Two caveats apply. Proposition 4 assumes an unbiased estimator, which neither BBSE nor MLLS is in finite samples. And $\hat\kappa$ is estimated from the same data as $\hat w$, so the oracle result does not transfer exactly. The shrunk weights are still computed from the estimation data alone, so Proposition 3 applies to them without change. Whether shrinkage helps is therefore an empirical question.

**Proposition 5** (bound-corrected weighted CP). Let $\hat w$ and $t\ge0$ be computed from the estimation data, and let $C^{\mathrm{BC}}$ be the set defined in Section 3.7. Then

$$Q\big(Y\in C^{\mathrm{BC}}(X)\big)\ \ge\ 1-\alpha-\mathbb E\big[(\mathrm{TV}(\hat w)-t)_+\,\mathbf 1\{t\le\alpha/2\}\big],$$

where the probability is marginal over the calibration data and the test point, and the expectation is over the estimation data.

**Corollary 1** (valid error bound). If $t$ is an upper confidence bound for the weight error at level $1-\delta$, that is, $\Pr\{\mathrm{TV}(\hat w)>t\}\le\delta$ over the estimation data, then $Q(Y\in C^{\mathrm{BC}}(X))\ge1-\alpha-\delta$. If $t\ge\mathrm{TV}(\hat w)$ almost surely, the coverage is at least $1-\alpha$.

**What is and is not guaranteed.** Proposition 5 is an exact inequality and needs no assumption on how $t$ is obtained. Its excess term is controlled, however, only if $t$ really bounds the weight error, and Corollary 1 needs exactly that. *Our bootstrap quantile is not shown to be such a bound.* It is centred at $\hat w$, so it measures the sampling variability of the estimator but ignores its bias (from clipping, from finite-sample bias of BBSE and MLLS, and from model misspecification). We have not established bootstrap consistency for these estimators. And the bootstrap cannot detect a violation of the label-shift assumption. For these reasons, the nominal level of WCP-BBSE-BC and WCP-MLLS-BC is only *approximate*. We therefore evaluate empirically how often $t$ falls below the true weight error and how large the excess term of Proposition 5 is (Section 6.3). A fully rigorous version would replace the bootstrap by a valid upper confidence bound for $\mathrm{TV}(\hat w)$, for example by propagating finite-sample confidence intervals through the BBSE linear system as Si et al. do for PAC prediction sets [@si2024pac]. We leave this for future work.
