## 8. Docx export and submission package instructions

**A. The manuscript file**

1. The file `Manuscript_LabelShift_Conformal.docx` is already assembled: title page, highlights, abstract, keywords, main text, tables, figures, declarations, references and appendices. It uses Times New Roman 12 pt, 1.5 line spacing and continuous line numbers, which reviewers find useful.
2. Open it in Microsoft Word or WPS. Author names, affiliation, e-mail and funding are already filled in. Search for `[INSERT` to find what is left: ORCIDs (optional; delete the line if not used), the GitHub URL and Zenodo DOI, and the submission date in the cover letter. Then delete every italic instruction in square brackets.
3. Equations are written as Unicode text with sub- and superscripts. For a typeset version, either retype the display equations with Word's Equation editor (Insert → Equation → LaTeX mode, then paste the LaTeX from the `.md` source), or submit the LaTeX version (see D).
4. Make sure the figures are placed after the paragraph where they are first cited, and that the captions follow the "Fig. 1." style.
5. Save as `.docx`, not `.doc` or `.pdf`. Editorial Manager builds the PDF itself.

**B. Separate files Elsevier asks for**

| File | What to upload | Item type in Editorial Manager |
|---|---|---|
| `CoverLetter.docx` | Cover letter (Section 1 of this package) | Cover Letter |
| `Highlights.docx` | The 5 highlights only, one per line | Highlights |
| `Manuscript.docx` | Main manuscript with embedded figures and tables | Manuscript |
| `Fig1.tiff` … `Fig5.tiff` | High-resolution figures (300 dpi, LZW TIFF, from `figures/`) | Figure |
| `Supplementary_Code_Results.zip` | Repository snapshot: code, CSV results, logs, README | Supplementary Material |
| `Declaration_of_Interest.docx` | Generated with Elsevier's declaration tool | Declaration of Interest Statement |
| Graphical abstract (optional) | `figures/fig1_pipeline.png` can serve; minimum 531 × 1328 px (h × w) | Graphical Abstract |

*The Elsevier generative-AI policy says general-purpose AI image tools must not be used to make graphical abstracts. Fig. 1 was drawn with matplotlib code, so it is acceptable.*

**C. Building the supplementary zip**

From the repository root (PowerShell):

```
Compress-Archive -Path lsconf\lsconf, lsconf\scripts, lsconf\results, lsconf\figures, lsconf\README.md, lsconf\requirements.txt, lsconf\environment.yml, lsconf\LICENSE, lsconf\CITATION.cff -DestinationPath Supplementary_Code_Results.zip
```

or on Linux/macOS: `zip -r Supplementary_Code_Results.zip lsconf -x "*/__pycache__/*"`. Check that the zip is below the journal's file-size limit (the current limit is shown in Editorial Manager at upload time).

**D. LaTeX alternative**

Elsevier accepts LaTeX through the `elsarticle` class with numbered references (`\documentclass[review]{elsarticle}`, `\bibliographystyle{elsarticle-num}`). The Markdown sources keep all equations in LaTeX syntax, and `refs.bib` can be used directly. The `venue-templates` skill installed on this machine contains an elsarticle scaffold.

**E. Before pressing "Submit"**

* Compile the PDF in Editorial Manager and read it end to end: check that every figure, table and equation appears correctly.
* Check that the number of references cited in the text matches the reference list (the build script reports this: 42 of 42).
* Re-run `python paper/verify_refs.py paper/refs.bib` after any change to the bibliography.

## 9. Final assembly checklist

| ☐ | Item | Notes |
|---|---|---|
| ☐ | Manuscript `.docx` with all `[INSERT …]` placeholders filled | Search for `[INSERT` and `[EDIT` |
| ☐ | Title page: full names, affiliations with postal addresses and "China", corresponding author email, ORCIDs | Use official English institution names |
| ☐ | Highlights file: 3–5 bullets, ≤ 85 characters each | Separate file |
| ☐ | Abstract ≤ 250 words; keywords 5–8 | Check against the current AIJ Guide for Authors |
| ☐ | Figures as separate TIFF/PNG files at ≥ 300 dpi | In `figures/` |
| ☐ | All tables editable (Word tables, not images) | Already the case |
| ☐ | Supplementary zip with code, data loaders, results, README | See C |
| ☐ | Cover letter addressed to the current Editor(s)-in-Chief by name | Look up names on the journal homepage |
| ☐ | Declaration of competing interest (Elsevier tool) | |
| ☐ | CRediT statement matches real contributions | |
| ☐ | Funding statement with real grant numbers | |
| ☐ | Data availability statement with working links | Test every URL |
| ☐ | Generative-AI declaration included and accurate | Mandatory under Elsevier policy |
| ☐ | All authors have approved the final version and the submission | Required by Elsevier |
| ☐ | Metadata ready for the online form: author list and order, affiliations, ORCIDs, emails, suggested reviewers, classifications | |
| ☐ | Full results reproduced on a second machine by a co-author (recommended) | Run `bash scripts/run_all.sh` and compare the CSVs |
| ☐ | Professional language check of the final text | Institution or Elsevier Language Editing Services |
