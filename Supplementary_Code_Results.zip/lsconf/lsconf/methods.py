"""Weight estimation and the full set of conformal methods for one shift draw.

Shared by scripts/run_experiments.py (simulated shift) and
scripts/run_natural_shift.py (natural shift across Covertype areas). The
order of random-number use is fixed, so results are reproducible.

Bound-corrected weighted CP (WCP-*-BC, Section 3.7 of the paper)
-----------------------------------------------------------------
Proposition 3 says weighted CP with weights w_hat loses at most
TV(w_hat) = 0.5 * sum_y pi_y |w_hat_y - w_y| of coverage. We estimate a
(1 - delta) upper quantile t of that error from the bootstrap replicates
already computed for shrinkage, and run weighted CP at level alpha - t.
If t > alpha / 2 (the estimated error would use up more than half of the
miscoverage budget) we fall back to Mondrian CP, which is valid under any
label shift. The decision uses only the estimation data, never the
calibration or test data.
"""
from __future__ import annotations

import numpy as np

from . import conformal as C
from . import weights as W


def estimate_weights(yhat_est, y_est, yhat_unl, p_unl, pi, boot, rng, kappas=(), no_mlls=False):
    est_w, boots, kap = {}, {}, {}
    est_w["bbse"] = W.bbse(yhat_est, y_est, yhat_unl, pi)
    boots["bbse"] = W.bootstrap_bbse(yhat_est, y_est, yhat_unl, pi, boot, rng)
    est_w["bbse_js"], kap["bbse_js"] = W.js_shrink(est_w["bbse"], boots["bbse"], pi)
    for k in kappas:
        est_w[f"bbse_k{k:g}"] = W.normalise(1 + k * (est_w["bbse"] - 1), pi)
    if not no_mlls:
        est_w["mlls"] = W.mlls(p_unl, pi)
        boots["mlls"] = W.bootstrap_mlls(p_unl, pi, boot, rng)
        est_w["mlls_js"], kap["mlls_js"] = W.js_shrink(est_w["mlls"], boots["mlls"], pi)
    return est_w, boots, kap


def bootstrap_tv_quantile(w_hat, w_boot, pi, delta):
    """(1 - delta) quantile of 0.5 * sum_y pi_y |w*_y - w_hat_y| over replicates."""
    tv = 0.5 * (np.abs(w_boot - w_hat[None, :]) @ pi)
    return float(np.quantile(tv, 1 - delta))


def all_sets(cal_s_true, cal_y, test_S, est_w, boots, pi, alpha, delta=0.1):
    """Return {method: prediction-set matrix} and {method: extra info}."""
    sets = {
        "scp": C.split_cp(cal_s_true, test_S, alpha),
        "mondrian": C.mondrian_cp(cal_s_true, cal_y, test_S, alpha),
    }
    for name, w in est_w.items():
        sets[f"wcp_{name}"] = C.weighted_cp(cal_s_true, cal_y, test_S, w, alpha)
    info = {}
    for name in ("bbse", "mlls"):
        if name not in boots:
            continue
        t = bootstrap_tv_quantile(est_w[name], boots[name], pi, delta)
        fallback = t > alpha / 2
        key = f"wcp_{name}_bc"
        sets[key] = sets["mondrian"] if fallback else C.weighted_cp(
            cal_s_true, cal_y, test_S, est_w[name], alpha - t)
        info[key] = {"bc_t": t, "bc_fallback": float(fallback)}
    return sets, info
