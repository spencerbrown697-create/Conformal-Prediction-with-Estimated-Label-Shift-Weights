"""Split conformal classifiers: standard, class-conditional (Mondrian) and
label-shift weighted (Tibshirani et al., 2019; Podkopaev and Ramdas, 2021).

All predictors return a boolean matrix S of shape (n_test, K) with
S[i, k] = True when label k is in the prediction set of test point i.
"""
from __future__ import annotations

import numpy as np


# ----------------------------------------------------------------- scores
def lac_scores(prob: np.ndarray) -> np.ndarray:
    """Least-ambiguous classifier score 1 - p(y|x) for every label."""
    return 1.0 - prob


def aps_scores(prob: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """Randomised adaptive prediction sets score (Romano et al., 2020).

    s(x, y) = sum of probabilities strictly larger than p(y|x) + U * p(y|x).
    """
    order = np.argsort(-prob, axis=1)
    p_sorted = np.take_along_axis(prob, order, axis=1)
    cum_before = np.cumsum(p_sorted, axis=1) - p_sorted
    u = rng.uniform(size=(prob.shape[0], 1))
    s_sorted = cum_before + u * p_sorted
    s = np.empty_like(prob)
    np.put_along_axis(s, order, s_sorted, axis=1)
    return s


# ------------------------------------------------------------ quantiles
def conformal_quantile(scores: np.ndarray, alpha: float) -> float:
    """ceil((n+1)(1-alpha))-th smallest score; +inf if that exceeds n."""
    n = len(scores)
    k = int(np.ceil((n + 1) * (1 - alpha)))
    if k > n:
        return np.inf
    return float(np.sort(scores)[k - 1])


def weighted_quantile(sorted_scores: np.ndarray, sorted_w: np.ndarray,
                      w_test: float, alpha: float) -> float:
    """(1-alpha) quantile of sum_i p_i delta_{s_i} + p_{n+1} delta_{+inf},
    with p_i proportional to the calibration weights and p_{n+1} to w_test."""
    total = sorted_w.sum() + w_test
    if total <= 0:
        return np.inf
    cdf = np.cumsum(sorted_w) / total
    hit = np.searchsorted(cdf, 1 - alpha - 1e-12, side="left")
    return np.inf if hit >= len(sorted_scores) else float(sorted_scores[hit])


# ----------------------------------------------------------- predictors
def split_cp(cal_s_true, test_s, alpha):
    t = conformal_quantile(cal_s_true, alpha)
    return test_s <= t


def mondrian_cp(cal_s_true, cal_y, test_s, alpha):
    K = test_s.shape[1]
    t = np.array([conformal_quantile(cal_s_true[cal_y == k], alpha) for k in range(K)])
    return test_s <= t[None, :]


def weighted_cp(cal_s_true, cal_y, test_s, w, alpha):
    """Label-shift weighted CP. The threshold for candidate label k depends on
    the test-point weight w[k], so we compute K thresholds once."""
    order = np.argsort(cal_s_true)
    s_sorted = cal_s_true[order]
    w_sorted = w[cal_y[order]]
    t = np.array([weighted_quantile(s_sorted, w_sorted, w[k], alpha)
                  for k in range(len(w))])
    return test_s <= t[None, :]


# -------------------------------------------------------------- metrics
def evaluate(S: np.ndarray, y: np.ndarray, min_class_n: int = 20):
    covered = S[np.arange(len(y)), y]
    per_class = [covered[y == k].mean() for k in np.unique(y)
                 if (y == k).sum() >= min_class_n]
    return {
        "coverage": float(covered.mean()),
        "size": float(S.sum(axis=1).mean()),
        "worst_class_cov": float(min(per_class)) if per_class else np.nan,
        "empty_rate": float((S.sum(axis=1) == 0).mean()),
    }
