"""Dataset loading and splitting.

All datasets are public. Digits ships with scikit-learn; the others are fetched
once through scikit-learn's official fetchers and cached under the scikit-learn
data home (default: ~/scikit_learn_data).

    digits     load_digits()                     1,797 x 64,   10 classes
    pendigits  fetch_openml(data_id=32)         10,992 x 16,   10 classes
    satimage   fetch_openml(data_id=182)         6,430 x 36,    6 classes
    letter     fetch_openml(data_id=6)          20,000 x 16,   26 classes
    covtype    fetch_covtype(), stratified subsample of 30,000 x 54, 7 classes
"""
from __future__ import annotations

import numpy as np
from sklearn.datasets import fetch_covtype, fetch_openml, load_digits
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

DATASETS = ["digits", "pendigits", "satimage", "letter", "covtype"]
OPENML_IDS = {"pendigits": 32, "satimage": 182, "letter": 6}
COVTYPE_N = 30_000


def load_dataset(name: str, data_home: str | None = None):
    """Return (X, y) with X float32 and y integer-coded 0..K-1."""
    if name == "digits":
        X, y = load_digits(return_X_y=True)
    elif name in OPENML_IDS:
        X, y = fetch_openml(data_id=OPENML_IDS[name], return_X_y=True,
                            as_frame=False, parser="auto", data_home=data_home)
    elif name == "covtype":
        X, y = fetch_covtype(return_X_y=True, data_home=data_home)
        # Fixed subsample (seed 0) so CPU runs stay short; stratified, so the
        # natural class imbalance of Covertype is preserved.
        X, _, y, _ = train_test_split(X, y, train_size=COVTYPE_N,
                                      stratify=y, random_state=0)
    else:
        raise ValueError(f"unknown dataset {name!r}")
    y = LabelEncoder().fit_transform(np.asarray(y))
    return np.asarray(X, dtype=np.float32), y.astype(np.int64)


def split_source(X, y, seed: int, fracs=(0.5, 0.1, 0.2, 0.2)):
    """Stratified split into train / est / cal / pool.

    train : fits the classifier
    est   : labelled source data used only for the BBSE confusion matrix
    cal   : conformal calibration set
    pool  : source of target-domain points (resampled under label shift)
    """
    assert abs(sum(fracs) - 1) < 1e-9
    idx = np.arange(len(y))
    rest_frac = 1 - fracs[0]
    tr, rest = train_test_split(idx, test_size=rest_frac, stratify=y, random_state=seed)
    est, rest2 = train_test_split(rest, train_size=fracs[1] / rest_frac,
                                  stratify=y[rest], random_state=seed + 1)
    cal, pool = train_test_split(rest2, train_size=fracs[2] / (fracs[2] + fracs[3]),
                                 stratify=y[rest2], random_state=seed + 2)
    return tr, est, cal, pool
