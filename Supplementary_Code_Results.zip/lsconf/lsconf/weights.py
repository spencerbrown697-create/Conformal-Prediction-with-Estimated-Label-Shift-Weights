"""Label-shift importance weights w_y = q_y / pi_y.

Estimators
----------
bbse   Black-box shift estimation (Lipton et al., 2018): solve C w = mu, where
       C[i, j] = P_source(yhat = i, y = j) and mu[i] = P_target(yhat = i).
mlls   Maximum-likelihood label shift via EM (Saerens et al., 2002).
*_js   Our shrinkage step: a bootstrap estimate of the estimator's variance
       sets how far the weights are pulled back towards 1 (no shift), in the
       spirit of positive-part James-Stein estimation.

Every estimate is clipped at 0 and renormalised so that sum_y pi_y w_y = 1,
i.e. q = pi * w is a probability vector.
"""
from __future__ import annotations

import numpy as np


def normalise(w: np.ndarray, pi: np.ndarray) -> np.ndarray:
    w = np.clip(w, 0.0, None)
    s = float(pi @ w)
    return w / s if s > 0 else np.ones_like(w)


def bbse(yhat_src: np.ndarray, y_src: np.ndarray, yhat_tgt: np.ndarray,
         pi: np.ndarray) -> np.ndarray:
    K = len(pi)
    C = np.zeros((K, K))
    np.add.at(C, (yhat_src, y_src), 1.0)
    C /= len(y_src)
    mu = np.bincount(yhat_tgt, minlength=K) / len(yhat_tgt)
    w, *_ = np.linalg.lstsq(C, mu, rcond=None)
    return normalise(w, pi)


def mlls(prob_tgt: np.ndarray, pi: np.ndarray, n_iter: int = 500,
         tol: float = 1e-8) -> np.ndarray:
    q = pi.copy()
    for _ in range(n_iter):
        r = prob_tgt * (q / pi)
        r /= r.sum(axis=1, keepdims=True)
        q_new = r.mean(axis=0)
        if np.abs(q_new - q).max() < tol:
            q = q_new
            break
        q = q_new
    return normalise(q / pi, pi)


def js_shrink(w_hat: np.ndarray, w_boot: np.ndarray, pi: np.ndarray):
    """Positive-part shrinkage of w_hat towards the all-ones vector.

    kappa = max(0, 1 - v / d2), where
      v  = sum_y pi_y Var_boot(w_y)     (estimated variance, pi-weighted)
      d2 = sum_y pi_y (w_hat_y - 1)^2   (squared distance from 'no shift')
    Returns the shrunk weights and kappa.
    """
    v = float(pi @ w_boot.var(axis=0, ddof=1))
    d2 = float(pi @ (w_hat - 1.0) ** 2)
    kappa = 0.0 if d2 <= 0 else max(0.0, 1.0 - v / d2)
    return normalise(1.0 + kappa * (w_hat - 1.0), pi), kappa


def bootstrap_bbse(yhat_src, y_src, yhat_tgt, pi, B, rng):
    n, m = len(y_src), len(yhat_tgt)
    out = np.empty((B, len(pi)))
    for b in range(B):
        i = rng.integers(0, n, n)
        j = rng.integers(0, m, m)
        out[b] = bbse(yhat_src[i], y_src[i], yhat_tgt[j], pi)
    return out


def bootstrap_mlls(prob_tgt, pi, B, rng):
    m = len(prob_tgt)
    out = np.empty((B, len(pi)))
    for b in range(B):
        out[b] = mlls(prob_tgt[rng.integers(0, m, m)], pi, n_iter=200)
    return out


def tv_error(w_hat: np.ndarray, w_true: np.ndarray, pi: np.ndarray) -> float:
    """Total-variation distance between the label-shift models implied by
    w_hat and w_true: 0.5 * sum_y pi_y |w_hat_y - w_true_y|."""
    return 0.5 * float(pi @ np.abs(w_hat - w_true))
