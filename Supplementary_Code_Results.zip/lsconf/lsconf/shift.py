"""Simulated label shift.

Label shift keeps p(x | y) fixed and changes p(y). We draw target class
proportions q from a Dirichlet distribution (Lipton et al., 2018) and then
draw target points class by class, with replacement, from a held-out pool
of source data. The pool is disjoint from the training, estimation and
calibration splits, so p(x | y) is unchanged by construction.
"""
from __future__ import annotations

import numpy as np

# name -> Dirichlet concentration (None = no shift)
SHIFTS = {"none": None, "dir10": 10.0, "dir1": 1.0, "dir0.1": 0.1}


def draw_target_proportions(pi: np.ndarray, shift: str, rng: np.random.Generator):
    conc = SHIFTS[shift]
    if conc is None:
        return pi.copy()
    q = rng.dirichlet(conc * np.ones(len(pi)))
    # Guard against exact zeros from extreme draws; keeps the counts well defined.
    q = np.maximum(q, 1e-12)
    return q / q.sum()


def sample_by_class(pool_idx: np.ndarray, pool_y: np.ndarray, q: np.ndarray,
                    m: int, rng: np.random.Generator):
    """Draw m indices from pool with class counts ~ Multinomial(m, q)."""
    counts = rng.multinomial(m, q)
    out = []
    for k, c in enumerate(counts):
        if c == 0:
            continue
        members = pool_idx[pool_y == k]
        out.append(rng.choice(members, size=c, replace=True))
    return np.concatenate(out), counts
