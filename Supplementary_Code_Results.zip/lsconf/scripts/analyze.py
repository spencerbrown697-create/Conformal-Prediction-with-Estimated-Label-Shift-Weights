"""Summarise a results CSV: seed-level means, mean +/- std over seeds, and
paired significance tests.

    python scripts/analyze.py results/main_logreg.csv --tag main

Writes results/tables/<tag>_summary.csv, <tag>_tests.csv and <tag>_bound.csv.

Statistical unit = seed. For every seed we average over the shift draws, so
each method has one number per seed (30 in the main run). Paired comparisons
use the two-sided Wilcoxon signed-rank test and a percentile bootstrap 95% CI
(10,000 resamples) for the mean paired difference. Effect sizes: the
matched-pairs rank-biserial correlation r_rb (in [-1, 1]) and Cohen's d_z
(mean difference / SD of differences). p-values are Holm-adjusted within each
metric family across all datasets, shift levels and comparisons.

Also writes <tag>_bc_calibration.csv: for the bound-corrected methods, how
often the bootstrap quantile t is below the true weight error, and the size of
the excess term of Proposition 5, E[(TV - t)_+ 1{t <= alpha/2}].
"""
from __future__ import annotations

import argparse
import os

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

METRICS = ["coverage", "size", "worst_class_cov", "tv_err", "undercov", "bc_fallback"]
COMPARISONS = [  # (ours, reference)
    ("wcp_bbse_js", "wcp_bbse"),
    ("wcp_mlls_js", "wcp_mlls"),
    ("wcp_mlls_js", "mondrian"),
    ("wcp_mlls_js", "scp"),
    ("wcp_mlls_bc", "mondrian"),
    ("wcp_mlls_bc", "wcp_mlls"),
]


def holm(p):
    p = np.asarray(p, float)
    order = np.argsort(p)
    m = len(p)
    adj = np.empty(m)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, min(1.0, (m - rank) * p[i]))
        adj[i] = running
    return adj


def boot_ci(x, rng, B=10_000):
    x = np.asarray(x)
    means = x[rng.integers(0, len(x), (B, len(x)))].mean(axis=1)
    return np.percentile(means, [2.5, 97.5])


def effect_sizes(diff):
    """Matched-pairs rank-biserial correlation and Cohen's d_z."""
    d = np.asarray(diff, float)
    nz = d[d != 0]
    if len(nz) == 0:
        r_rb = 0.0
    else:
        ranks = pd.Series(np.abs(nz)).rank().to_numpy()
        w_pos, w_neg = ranks[nz > 0].sum(), ranks[nz < 0].sum()
        r_rb = (w_pos - w_neg) / (w_pos + w_neg)
    sd = d.std(ddof=1) if len(d) > 1 else 0.0
    d_z = d.mean() / sd if sd > 0 else np.nan
    return float(r_rb), float(d_z)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv")
    ap.add_argument("--tag", required=True)
    ap.add_argument("--tol", type=float, default=0.02,
                    help="a draw is under-covered if coverage < 1-alpha-tol")
    a = ap.parse_args()
    out_dir = os.path.join(os.path.dirname(a.csv), "tables")
    os.makedirs(out_dir, exist_ok=True)

    df = pd.read_csv(a.csv)
    df["undercov"] = (df["coverage"] < (1 - df["alpha"]) - a.tol).astype(float)
    metrics = [m for m in METRICS if m in df.columns]
    keys = ["dataset", "shift", "method"]

    # ---- seed-level means, then mean/std across seeds
    seed = df.groupby(keys + ["seed"])[metrics].mean().reset_index()
    summ = seed.groupby(keys)[metrics].agg(["mean", "std"])
    summ.columns = [f"{m}_{s}" for m, s in summ.columns]
    summ["n_seeds"] = seed.groupby(keys)["seed"].nunique()
    summ.reset_index().to_csv(os.path.join(out_dir, f"{a.tag}_summary.csv"), index=False)

    # ---- paired tests on seed means
    rng = np.random.default_rng(0)
    rows = []
    for (ds, sh), g in seed.groupby(["dataset", "shift"]):
        piv = {m: g.pivot(index="seed", columns="method", values=m) for m in metrics}
        for ours, ref in COMPARISONS:
            for m in ["coverage", "size", "worst_class_cov", "tv_err"]:
                P = piv[m]
                if ours not in P or ref not in P:
                    continue
                diff = (P[ours] - P[ref]).dropna().to_numpy()
                if len(diff) == 0:
                    continue
                if len(diff) < 5 or np.allclose(diff, 0):
                    p = 1.0
                else:
                    p = wilcoxon(diff, zero_method="zsplit").pvalue
                lo, hi = boot_ci(diff, rng)
                r_rb, d_z = effect_sizes(diff)
                rows.append(dict(dataset=ds, shift=sh, ours=ours, ref=ref, metric=m,
                                 mean_diff=diff.mean(), ci_lo=lo, ci_hi=hi, r_rb=r_rb, d_z=d_z,
                                 p_raw=p, n=len(diff)))
    tests = pd.DataFrame(rows)
    if len(tests):
        tests["p_holm"] = tests.groupby("metric")["p_raw"].transform(lambda s: holm(s.values))
    tests.to_csv(os.path.join(out_dir, f"{a.tag}_tests.csv"), index=False)

    # ---- SECONDARY, POST-HOC: pool datasets within each shift level.
    # Seeds are independent across datasets, so each shift level gives
    # 5 datasets x n_seeds paired values. Small family -> Holm over 24 tests.
    prow = []
    for sh, g in seed.groupby("shift"):
        for ours, ref, mets in [("wcp_bbse_js", "wcp_bbse", ["tv_err", "coverage"]),
                                ("wcp_mlls_js", "wcp_mlls", ["tv_err", "coverage"]),
                                ("wcp_mlls_bc", "mondrian", ["coverage", "size"])]:
            for m in mets:
                P = g.pivot_table(index=["dataset", "seed"], columns="method", values=m)
                if ours not in P or ref not in P:
                    continue
                diff = (P[ours] - P[ref]).dropna().to_numpy()
                if len(diff) == 0:
                    continue
                p = 1.0 if np.allclose(diff, 0) else wilcoxon(diff, zero_method="zsplit").pvalue
                lo, hi = boot_ci(diff, rng)
                r_rb, d_z = effect_sizes(diff)
                prow.append(dict(shift=sh, ours=ours, ref=ref, metric=m, n=len(diff),
                                 mean_diff=diff.mean(), ci_lo=lo, ci_hi=hi, r_rb=r_rb, d_z=d_z,
                                 p_raw=p))
    pooled = pd.DataFrame(prow)
    if len(pooled):
        pooled["p_holm"] = holm(pooled["p_raw"].values)
    pooled.to_csv(os.path.join(out_dir, f"{a.tag}_pooled_posthoc.csv"), index=False)
    print(pooled.round(4).to_string())

    # ---- empirical check of the TV coverage bound, per draw
    w = df[df["tv_err"].notna() & (df["method"] != "wcp_oracle")].copy()
    w["shortfall"] = (1 - w["alpha"]) - w["coverage"]
    w["excess"] = w["shortfall"] - w["tv_err"]  # bound says E[excess] <= 0
    bound = w.groupby(["dataset", "method"]).agg(
        mean_tv=("tv_err", "mean"), mean_shortfall=("shortfall", "mean"),
        frac_excess_gt_0=("excess", lambda s: float((s > 0).mean())),
        frac_excess_gt_2se=("excess", lambda s: float((s > 0.0134).mean())),
        corr_tv_shortfall=("shortfall", lambda s: float(np.corrcoef(s, w.loc[s.index, "tv_err"])[0, 1])
                           if s.std() > 0 and w.loc[s.index, "tv_err"].std() > 0 else np.nan),
    ).reset_index()
    bound.to_csv(os.path.join(out_dir, f"{a.tag}_bound.csv"), index=False)

    # ---- is the bootstrap quantile t an upper bound on the true weight error?
    if "bc_t" in df.columns and df["bc_t"].notna().any():
        key = ["dataset", "shift", "seed", "draw"]
        crow = []
        for est in ("bbse", "mlls"):
            bc = df[df.method == f"wcp_{est}_bc"][key + ["bc_t", "bc_fallback", "coverage", "alpha"]]
            raw = df[df.method == f"wcp_{est}"][key + ["tv_err"]]
            j = bc.merge(raw, on=key)
            if j.empty:
                continue
            j["used"] = j["bc_fallback"] == 0
            j["miss"] = j["tv_err"] > j["bc_t"]
            j["excess"] = (j["tv_err"] - j["bc_t"]).clip(lower=0) * j["used"]
            for (ds, sh), g in j.groupby(["dataset", "shift"]):
                u = g[g.used]
                crow.append(dict(dataset=ds, shift=sh, method=f"wcp_{est}_bc", n_draws=len(g),
                                 frac_weights_used=float(g.used.mean()),
                                 frac_t_below_tv=float(g.miss.mean()),
                                 frac_t_below_tv_when_used=float(u.miss.mean()) if len(u) else np.nan,
                                 mean_excess_term=float(g.excess.mean()),
                                 max_excess_term=float(g.excess.max()),
                                 mean_t=float(g.bc_t.mean()), mean_tv=float(g.tv_err.mean()),
                                 mean_coverage=float(g.coverage.mean())))
        pd.DataFrame(crow).to_csv(os.path.join(out_dir, f"{a.tag}_bc_calibration.csv"), index=False)
    print(summ.round(3).to_string())
    print(tests.round(4).to_string())
    print(bound.round(3).to_string())


if __name__ == "__main__":
    main()
