"""Consistency checks between the result files, the manuscript sources and the
reproduction script. Exits with status 1 if any check fails.

    python scripts/check_consistency.py

Checks
  1. every result CSV has exactly the rows its design implies
     (datasets x seeds x shift levels x draws x methods) and the expected methods;
  2. every table placed in the manuscript exists in paper/tables_generated.md,
     every generated table is placed, and every placed table/figure is referenced;
  3. table and figure numbers appear in sequential order;
  4. every citation key exists in refs.bib and every bib entry is cited;
  5. row counts quoted in the text match the files;
  6. scripts/run_all.sh produces every result file used by make_tables.py.
"""
from __future__ import annotations

import os
import re
import sys

import pandas as pd

R = "results"
NINE = {"scp", "mondrian", "wcp_oracle", "wcp_bbse", "wcp_bbse_js", "wcp_bbse_bc",
        "wcp_mlls", "wcp_mlls_js", "wcp_mlls_bc"}
KAPPA = {"scp", "mondrian", "wcp_oracle", "wcp_bbse", "wcp_bbse_js", "wcp_bbse_bc"} | {
    f"wcp_bbse_k{k}" for k in ("0", "0.25", "0.5", "0.75", "1")}
D3 = 3
# file -> (n_datasets, n_seeds, n_shifts, n_draws, methods)
DESIGN = {
    "main_logreg.csv": (5, 30, 4, 10, NINE),
    "natural_covtype.csv": (1, 10, 3, 10, NINE),   # 3 target areas stored as 'shift'
    "abl_m100.csv": (D3, 5, 2, 10, NINE), "abl_m300.csv": (D3, 5, 2, 10, NINE),
    "abl_m1000.csv": (D3, 5, 2, 10, NINE), "abl_m3000.csv": (D3, 5, 2, 10, NINE),
    "abl_aps.csv": (D3, 5, 3, 10, NINE), "abl_hgb.csv": (D3, 5, 3, 10, NINE),
    "abl_hgb_es_covtype.csv": (1, 5, 3, 10, NINE),
    "abl_alpha0.05.csv": (D3, 5, 1, 10, NINE), "abl_alpha0.2.csv": (D3, 5, 1, 10, NINE),
    "abl_kappa.csv": (D3, 5, 3, 10, KAPPA),
}
PARTS = ["paper/part1_front_intro_method.md", "paper/part2_setup.md", "paper/part3_results_discussion.md",
         "paper/part5_declarations.md", "paper/part4_appendix.md"]
fails: list[str] = []


def check(ok, msg):
    print(("PASS " if ok else "FAIL ") + msg)
    if not ok:
        fails.append(msg)


# 1. result files
for f, (nd, ns, nsh, ndr, meths) in DESIGN.items():
    p = os.path.join(R, f)
    if not os.path.exists(p):
        check(False, f"{f}: missing")
        continue
    d = pd.read_csv(p)
    exp = nd * ns * nsh * ndr * len(meths)
    check(len(d) == exp, f"{f}: {len(d)} rows (design {nd}x{ns}x{nsh}x{ndr}x{len(meths)} = {exp})")
    check(set(d.method) == meths, f"{f}: method set {'matches' if set(d.method) == meths else sorted(set(d.method) ^ meths)}")
    check(d.groupby("dataset").seed.nunique().eq(ns).all(), f"{f}: {ns} seeds per dataset")
    check(not d.duplicated(["dataset", "seed", "shift", "draw", "method"]).any(), f"{f}: no duplicate rows")

# 2-3. tables and figures
text = "\n".join(open(p, encoding="utf-8").read() for p in PARTS)
gen = open("paper/tables_generated.md", encoding="utf-8").read()
generated = re.findall(r"^### (Table [A0-9]+)\.", gen, re.M)
placed = re.findall(r"\{\{TABLE:(Table [A0-9]+)\}\}", text)
inline = re.findall(r"^\*\*(Table [A0-9]+)\.\*\*", text, re.M)
check(set(placed) <= set(generated), f"placed tables exist: {sorted(set(placed) - set(generated)) or 'all'}")
check(set(generated) <= set(placed), f"generated tables placed: {sorted(set(generated) - set(placed)) or 'all'}")
body = re.sub(r"\{\{TABLE:[^}]+\}\}|^\*\*Table [A0-9]+\.\*\*", "", text, flags=re.M)
refs = set()
for m in re.finditer(r"Tables? ((?:A?\d+)(?:(?:–| and |, )A?\d+)*)", body):
    parts = re.split(r"–| and |, ", m.group(1))
    if "–" in m.group(1) and not parts[0].startswith("A"):
        refs |= {str(i) for i in range(int(parts[0]), int(parts[-1]) + 1)}
    refs |= set(parts)
all_tables = [t.split()[1] for t in placed + inline]
unref = [t for t in all_tables if t not in refs]
check(not unref, f"every table referenced in the text: {unref or 'yes'}")
main = [t for t in dict.fromkeys(re.findall(r"\{\{TABLE:Table (\d+)\}\}|\*\*Table (\d+)\.\*\*", text)) for t in t if t]
order = [int(x) for x in main]
check(order == list(range(1, len(order) + 1)), f"main tables in sequence: {order}")
apx = [x for x in dict.fromkeys(re.findall(r"(?:\{\{TABLE:Table |\*\*Table )(A\d)", text))]
check(apx == [f"A{i}" for i in range(1, len(apx) + 1)], f"appendix tables in sequence: {apx}")
figs = re.findall(r"\{\{FIG:([^|]+)\|\*\*Fig\. (\d+)\.\*\*", text)
check([int(n) for _, n in figs] == list(range(1, len(figs) + 1)), f"figures in sequence: {[n for _, n in figs]}")
for name, n in figs:
    check(os.path.exists(f"figures/{name}.png") and os.path.exists(f"figures/{name}.tiff"), f"Fig. {n} files exist ({name})")
    check(re.search(rf"Figs?\. {n}\b", re.sub(r"\{\{FIG:[^}]+\}\}", "", text)) is not None, f"Fig. {n} referenced in text")

# 4. citations
bib = set(re.findall(r"@\w+\{([^,]+),", open("paper/refs.bib", encoding="utf-8").read()))
cited = set()
for m in re.finditer(r"\[(@[^\]]+)\]", text):
    cited |= {k.strip().lstrip("@").split(",")[0] for k in m.group(1).split(";")}
check(cited <= bib, f"all citations in refs.bib: {sorted(cited - bib) or 'yes'} ({len(cited)} cited)")
check(bib <= cited, f"all bib entries cited: {sorted(bib - cited) or 'yes'} ({len(bib)} entries)")

# 5. row counts quoted in the text
for f in ("main_logreg.csv", "natural_covtype.csv"):
    n = len(pd.read_csv(os.path.join(R, f)))
    quoted = re.findall(rf"`results/{re.escape(f)}` \(([\d,]+) rows", text)
    check(all(int(q.replace(",", "")) == n for q in quoted), f"text row count for {f}: {quoted} vs {n:,}")

# 6. run_all.sh covers every results file used for tables
run_all = open("scripts/run_all.sh", encoding="utf-8").read()
for f in DESIGN:
    stem = f.replace(".csv", "")
    covered = (f in run_all) or (stem.startswith("abl_m") and "abl_m$m" in run_all) or \
              (stem.startswith("abl_alpha") and "abl_alpha$a" in run_all)
    check(covered, f"run_all.sh produces {f}")

print(f"\n{len(fails)} failure(s)")
sys.exit(1 if fails else 0)
