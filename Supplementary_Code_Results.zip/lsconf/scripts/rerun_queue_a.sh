#!/usr/bin/env bash
# Revision 3, queue A: natural shift with 10 seeds, then ablations re-run with the
# current code so that every results file contains the same method set.
set -euo pipefail
D3="satimage letter covtype"
python scripts/run_natural_shift.py --seeds 10 --draws 10 --out results/natural_covtype.csv
python scripts/run_experiments.py --datasets $D3 --model logreg --score aps --shifts none dir1 dir0.1 --seeds 5 --out results/abl_aps.csv
python scripts/run_experiments.py --datasets $D3 --model logreg --shifts dir1 --alpha 0.05 --seeds 5 --out results/abl_alpha0.05.csv
python scripts/run_experiments.py --datasets $D3 --model logreg --shifts none dir10 dir1 --kappas 0 0.25 0.5 0.75 1 --no-mlls --seeds 5 --out results/abl_kappa.csv
echo "queue A done"
