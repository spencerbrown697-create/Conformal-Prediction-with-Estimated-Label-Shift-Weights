#!/usr/bin/env bash
# Reproduces every result file, table and figure used in the paper.
# Run from the repository root. Total time on a 2-core Intel i3-6006U laptop:
# about 5 hours on one job (main ~2.5 h for 30 seeds, natural shift ~10 min, ablations ~2 h).
# run_experiments.py pins BLAS to one thread itself (see paper, Sec. 8.3).
set -euo pipefail
R=results
D3="satimage letter covtype"
run() { python scripts/run_experiments.py "$@"; }

# Main experiment, 30 seeds (Tables 3-8, A3-A4; Figures 2-4)
run --model logreg --seeds 30 --draws 10 --out $R/main_logreg.csv

# Natural shift: leave-one-wilderness-area-out on the full Covertype data (Section 6.6, Table 9, Figure 5)
python scripts/run_natural_shift.py --seeds 10 --draws 10 --out $R/natural_covtype.csv

# Ablations (Section 7), 5 seeds x 10 draws, three datasets
for m in 100 300 1000 3000; do
  run --datasets $D3 --model logreg --shifts none dir1 --m-unlab $m --seeds 5 --out $R/abl_m$m.csv
done
run --datasets $D3 --model logreg --shifts none dir10 dir1 --kappas 0 0.25 0.5 0.75 1 --no-mlls --seeds 5 --out $R/abl_kappa.csv
run --datasets $D3 --model logreg --score aps --shifts none dir1 dir0.1 --seeds 5 --out $R/abl_aps.csv
run --datasets $D3 --model hgb --shifts none dir1 dir0.1 --seeds 5 --out $R/abl_hgb.csv
# post-hoc check after diagnosing boosting divergence on Covertype (Sec. 7.4)
run --datasets covtype --model hgb_es --shifts none dir1 dir0.1 --seeds 5 --out $R/abl_hgb_es_covtype.csv
for a in 0.05 0.2; do
  run --datasets $D3 --model logreg --shifts dir1 --alpha $a --seeds 5 --out $R/abl_alpha$a.csv
done

# Statistics, tables, figures, and the numbers quoted in the text
python scripts/analyze.py $R/main_logreg.csv --tag main
for f in abl_hgb abl_aps abl_kappa; do python scripts/analyze.py $R/$f.csv --tag $f; done
# Optional (Sec. 8.3, Table 12): compare against a run made with multi-threaded BLAS,
# e.g. produced with OMP_NUM_THREADS=4 python scripts/run_experiments.py ... --out $R/main_logreg_multithreadBLAS.csv
[ -f $R/main_logreg_multithreadBLAS.csv ] && python scripts/compare_runs.py $R/main_logreg_multithreadBLAS.csv $R/main_logreg.csv
python scripts/make_tables.py
python scripts/make_figures.py
python scripts/claims_numbers.py > $R/tables/claims_numbers.txt
python scripts/check_consistency.py

# Manuscript files
python paper/build_docx.py paper/Manuscript_LabelShift_Conformal.docx
python paper/build_latex.py
