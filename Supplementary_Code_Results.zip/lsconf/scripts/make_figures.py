"""Draw the paper's figures from the result CSVs (300 dpi PNG + TIFF).

    python scripts/make_figures.py

Colours: Okabe-Ito subset (checked for colour-vision deficiency); every series
also has its own marker and line style, so colour is never the only cue.
"""
from __future__ import annotations

import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch  # noqa: E402
from matplotlib.ticker import MaxNLocator  # noqa: E402

R, F = "results", "figures"
os.makedirs(F, exist_ok=True)
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": "#e6e6e6", "grid.linewidth": 0.6,
                     "axes.edgecolor": "#888888", "legend.frameon": False,
                     "savefig.dpi": 300, "font.family": "DejaVu Sans"})

STYLE = {  # method -> (label, colour, marker, linestyle)
    "scp":         ("Split CP",              "#D55E00", "v", ":"),
    "mondrian":    ("Mondrian CP",           "#0072B2", "s", "-"),
    "wcp_bbse":    ("WCP-BBSE",              "#E69F00", "^", "--"),
    "wcp_bbse_js": ("WCP-BBSE-S (ours)",     "#CC79A7", "D", "-."),
    "wcp_mlls":    ("WCP-MLLS",              "#56B4E9", "x", "--"),
    "wcp_mlls_js": ("WCP-MLLS-S (ours)",     "#009E73", "o", "-"),
    "wcp_oracle":  ("WCP-oracle",            "#555555", "*", "-"),
}
DS = ["digits", "pendigits", "satimage", "letter", "covtype"]


def save(fig, name):
    fig.savefig(os.path.join(F, name + ".png"), bbox_inches="tight")
    fig.savefig(os.path.join(F, name + ".tiff"), bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)
    print("wrote", name)


def seed_means(df, keys):
    return df.groupby(keys + ["seed"])[["coverage", "size", "worst_class_cov", "tv_err", "kappa"]].mean().reset_index()


# ---------------------------------------------------------------- Figure 1
def fig_pipeline():
    fig, ax = plt.subplots(figsize=(9.0, 2.5))
    ax.set_axis_off()
    ax.set_xlim(0, 11.6)
    ax.set_ylim(0, 3)
    W, H = 1.95, 0.9
    boxes = [
        (0.1, 1.9, "Source data\n(labelled)", "#e8f1f8"),
        (0.1, 0.25, "Target data\n(unlabelled)", "#fdf0e0"),
        (2.45, 1.08, "Black-box\nclassifier f", "#f2f2f2"),
        (4.7, 1.08, "Weight estimate ŵ\n(BBSE or MLLS)", "#f2f2f2"),
        (6.95, 1.08, "Bootstrap shrinkage\nŵ_S = 1 + κ(ŵ − 1)", "#e3f4ee"),
        (9.2, 1.08, "Weighted conformal\nprediction sets", "#f2f2f2"),
    ]
    for x, y, t, c in boxes:
        ax.add_patch(FancyBboxPatch((x, y), W, H, boxstyle="round,pad=0.05", fc=c, ec="#666666", lw=0.8))
        ax.text(x + W / 2, y + H / 2, t, ha="center", va="center", fontsize=7.5)
    arrows = [((2.1, 2.3), (2.45, 1.75)), ((2.1, 0.7), (2.45, 1.25)), ((4.45, 1.53), (4.7, 1.53)),
              ((6.7, 1.53), (6.95, 1.53)), ((8.95, 1.53), (9.2, 1.53))]
    for a, b in arrows:
        ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=10, color="#444444", lw=0.9))
    ax.text(6.95 + W / 2, 0.7, "κ = max(0, 1 − v̂ / d̂²)", ha="center", fontsize=7, color="#333333")
    ax.text(9.2 + W / 2, 0.55, "calibration scores\nreweighted by ŵ_S", ha="center", fontsize=7, color="#333333")
    save(fig, "fig1_pipeline")


# ---------------------------------------------------------------- Figure 2
def fig_cov_size(main, shift="dir1"):
    sm = seed_means(main[main["shift"] == shift], ["dataset", "method"])
    fig, axes = plt.subplots(1, 5, figsize=(10, 2.5))
    for ax, ds in zip(axes, DS):
        g = sm[sm.dataset == ds].groupby("method")
        for meth in ["scp", "mondrian", "wcp_bbse", "wcp_mlls_js", "wcp_oracle"]:
            if meth not in g.groups:
                continue
            d = g.get_group(meth)
            lab, c, mk, _ = STYLE[meth]
            ax.errorbar(d["size"].mean(), d["coverage"].mean(), xerr=d["size"].std(),
                        yerr=d["coverage"].std(), fmt=mk, color=c, ms=6, lw=1, capsize=2, label=lab)
        ax.axhline(0.9, color="#333333", lw=0.8, ls="--")
        ax.set_title(ds)
        ax.xaxis.set_major_locator(MaxNLocator(3))
        ax.set_xlabel("Mean set size")
    axes[0].set_ylabel("Target coverage")
    axes[-1].legend(loc="center left", bbox_to_anchor=(1.02, 0.5), fontsize=8)
    fig.tight_layout()
    save(fig, f"fig2_coverage_vs_size_{shift}")


# ---------------------------------------------------------------- Figure 3
def fig_bound(main):
    d = main[main["tv_err"].notna() & main["method"].isin(["wcp_bbse", "wcp_mlls", "wcp_bbse_js", "wcp_mlls_js"])].copy()
    d["shortfall"] = (1 - d["alpha"]) - d["coverage"]
    bins = np.array([0, 0.02, 0.05, 0.1, 0.15, 0.2, 0.3, 0.5, 1.0])
    fig, ax = plt.subplots(figsize=(4.6, 3.3))
    for meth in ["wcp_bbse", "wcp_mlls", "wcp_bbse_js", "wcp_mlls_js"]:
        x = d[d.method == meth]
        idx = np.digitize(x["tv_err"], bins) - 1
        stats = x.groupby(idx).agg(tv=("tv_err", "mean"), sf=("shortfall", "mean"),
                                   se=("shortfall", lambda s: s.std(ddof=1) / np.sqrt(len(s)) if len(s) > 1 else 0),
                                   n=("shortfall", "size"))
        stats = stats[stats.n >= 10]
        lab, c, mk, ls = STYLE[meth]
        ax.errorbar(stats.tv, stats.sf, yerr=1.96 * stats.se, fmt=mk, ls=ls, color=c, ms=5, lw=1, capsize=2, label=lab)
    lim = max(0.05, float(d["tv_err"].quantile(0.99)))
    ax.plot([0, lim], [0, lim], color="#333333", lw=0.9, label="Bound: shortfall = TV")
    ax.axhline(0, color="#999999", lw=0.6)
    ax.set_xlim(0, lim)
    ax.set_xlabel("TV error of estimated weights, ½ Σ π_y |ŵ_y − w_y|")
    ax.set_ylabel("Coverage shortfall, (1 − α) − coverage")
    ax.legend(fontsize=7.5)
    save(fig, "fig3_shortfall_vs_tv")


# ---------------------------------------------------------------- Figure 4
def fig_m_unlab():
    parts = [pd.read_csv(os.path.join(R, f"abl_m{m}.csv")) for m in (100, 300, 1000, 3000)
             if os.path.exists(os.path.join(R, f"abl_m{m}.csv"))]
    if not parts:
        return
    d = pd.concat(parts)
    d = d[d["tv_err"].notna() & (d.method != "wcp_oracle")]
    sm = d.groupby(["dataset", "shift", "method", "m_unlab", "seed"])["tv_err"].mean().reset_index()
    shifts = ["none", "dir1"]
    dss = [x for x in DS if x in sm.dataset.unique()]
    fig, axes = plt.subplots(len(shifts), len(dss), figsize=(3 * len(dss), 4.6), sharex=True)
    axes = np.atleast_2d(axes)
    for i, sh in enumerate(shifts):
        for j, ds in enumerate(dss):
            ax = axes[i, j]
            for meth in ["wcp_bbse", "wcp_bbse_js", "wcp_mlls", "wcp_mlls_js"]:
                g = sm[(sm.dataset == ds) & (sm["shift"] == sh) & (sm.method == meth)].groupby("m_unlab")["tv_err"]
                if g.ngroups == 0:
                    continue
                lab, c, mk, ls = STYLE[meth]
                ax.errorbar(g.mean().index, g.mean().values, yerr=g.std().values, marker=mk, ls=ls,
                            color=c, ms=4, lw=1.2, capsize=2, label=lab)
            ax.set_xscale("log")
            ax.set_title(f"{ds}, shift = {sh}", fontsize=8.5)
            if j == 0:
                ax.set_ylabel("TV error of weights")
            if i == len(shifts) - 1:
                ax.set_xlabel("Unlabelled target sample size m")
    axes[0, -1].legend(loc="upper right", fontsize=7)
    fig.tight_layout()
    save(fig, "fig4_unlabelled_size")


# ---------------------------------------------------------------- Figure 5
def fig_kappa(main):
    d = main[main.method == "wcp_mlls_js"]
    order = ["none", "dir10", "dir1", "dir0.1"]
    fig, ax = plt.subplots(figsize=(4.6, 2.8))
    data = [d[d["shift"] == s]["kappa"].dropna().values for s in order]
    bp = ax.boxplot(data, widths=0.5, patch_artist=True, showfliers=False)
    for b in bp["boxes"]:
        b.set(facecolor="#e3f4ee", edgecolor="#009E73")
    for m in bp["medians"]:
        m.set(color="#333333")
    ax.set_xticks(range(1, 5), ["no shift", "Dir(10)", "Dir(1)", "Dir(0.1)"])
    ax.set_ylabel("Shrinkage factor κ (MLLS)")
    ax.set_xlabel("Label-shift severity")
    save(fig, "fig5_kappa_by_shift")


# ---------------------------------------------------------------- Figure 6
def fig_natural():
    p = os.path.join(R, "natural_covtype.csv")
    if not os.path.exists(p):
        return
    d = pd.read_csv(p)
    sm = d.groupby(["shift", "method", "seed"])["coverage"].mean().reset_index()
    areas = sorted(sm["shift"].unique())
    meths = ["scp", "mondrian", "wcp_oracle", "wcp_bbse", "wcp_mlls", "wcp_mlls_js", "wcp_mlls_bc"]
    style = dict(STYLE)
    style["wcp_mlls_bc"] = ("WCP-MLLS-BC (ours)", "#000000", "P", "-")
    fig, ax = plt.subplots(figsize=(7.2, 3.0))
    width = 0.8 / len(meths)
    for i, meth in enumerate(meths):
        g = sm[sm.method == meth].groupby("shift")["coverage"]
        x = np.arange(len(areas)) + (i - (len(meths) - 1) / 2) * width
        lab, c, mk, _ = style[meth]
        ax.errorbar(x, g.mean().reindex(areas).values, yerr=g.std().reindex(areas).values,
                    fmt=mk, color=c, ms=6, capsize=2, lw=1, label=lab)
    ax.axhline(0.9, color="#333333", ls="--", lw=0.8)
    ax.set_xticks(range(len(areas)), [a.replace("area:", "held-out: ") for a in areas])
    ax.set_ylabel("Target coverage")
    ax.legend(loc="center left", bbox_to_anchor=(1.01, 0.5), fontsize=7.5)
    save(fig, "fig6_natural_shift")


if __name__ == "__main__":
    fig_natural()
    fig_pipeline()
    p = os.path.join(R, "main_logreg.csv")
    if os.path.exists(p):
        main = pd.read_csv(p)
        for sh in ("dir1", "dir0.1"):
            fig_cov_size(main, sh)
        fig_bound(main)
        fig_kappa(main)
    fig_m_unlab()
