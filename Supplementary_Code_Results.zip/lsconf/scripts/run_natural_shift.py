"""Natural distribution shift on the full Covertype data (Section 6.6).

Covertype records which of four wilderness areas each 30 m cell lies in, and
the cover-type proportions differ strongly between areas. We train on all
areas except one and deploy on the held-out area. Unlike the simulated
experiments, nothing forces p(x | y) to be equal across areas, so this tests
the methods when the label-shift assumption is only approximately true.

Cache la Poudre is never used as the target: it contains the only examples of
cover type 4 (cottonwood/willow), a class that would be new at test time,
which no label-shift method can handle.

    python scripts/run_natural_shift.py --out results/natural_covtype.csv
"""
from __future__ import annotations

import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import argparse  # noqa: E402
import sys  # noqa: E402
import time  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from sklearn.datasets import fetch_covtype  # noqa: E402
from sklearn.linear_model import LogisticRegression  # noqa: E402
from sklearn.model_selection import train_test_split  # noqa: E402
from sklearn.pipeline import make_pipeline  # noqa: E402
from sklearn.preprocessing import StandardScaler  # noqa: E402

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from lsconf import conformal as C  # noqa: E402
from lsconf import methods as M  # noqa: E402
from lsconf import weights as W  # noqa: E402
from lsconf.data import split_source  # noqa: E402

AREAS = ["Rawah", "Neota", "Comanche Peak", "Cache la Poudre"]
TARGETS = [0, 1, 2]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--draws", type=int, default=10)
    ap.add_argument("--n-source", type=int, default=60_000, help="stratified source subsample")
    ap.add_argument("--alpha", type=float, default=0.1)
    ap.add_argument("--m-unlab", type=int, default=500)
    ap.add_argument("--m-eval", type=int, default=2000)
    ap.add_argument("--boot", type=int, default=100)
    ap.add_argument("--bc-delta", type=float, default=0.1)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    print(f"threads OMP={os.environ['OMP_NUM_THREADS']} | {vars(a)}", flush=True)

    X, y = fetch_covtype(return_X_y=True)
    y = (y - 1).astype(np.int64)
    area = X[:, 10:14].argmax(1)
    X = np.delete(X, np.s_[10:14], axis=1).astype(np.float32)  # drop the area indicators
    K = 7
    rows, t_start = [], time.time()
    for tgt in TARGETS:
        src_all = np.where(area != tgt)[0]
        tgt_all = np.where(area == tgt)[0]
        q = np.bincount(y[tgt_all], minlength=K) / len(tgt_all)  # population target proportions
        for s in range(a.seeds):
            t0 = time.time()
            src, _ = train_test_split(src_all, train_size=a.n_source, stratify=y[src_all], random_state=1000 * s)
            Xs, ys = X[src], y[src]
            tr, est, cal, _ = split_source(Xs, ys, seed=1000 * s)
            model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=3000, C=1.0)).fit(Xs[tr], ys[tr])
            pi = np.bincount(ys[tr], minlength=K) / len(tr)
            w_true = W.normalise(q / pi, pi)
            p_est, p_cal = model.predict_proba(Xs[est]), model.predict_proba(Xs[cal])
            cal_s_true = C.lac_scores(p_cal)[np.arange(len(cal)), ys[cal]]
            yhat_est = p_est.argmax(1)
            src_acc = float((model.predict(Xs[cal]) == ys[cal]).mean())
            for d in range(a.draws):
                rng = np.random.default_rng([s, 100 + tgt, d])
                pick = rng.choice(tgt_all, size=a.m_unlab + a.m_eval, replace=False)
                unl, ev = pick[:a.m_unlab], pick[a.m_unlab:]
                p_unl, p_ev = model.predict_proba(X[unl]), model.predict_proba(X[ev])
                t_w = time.time()
                w_est, boots, kap = M.estimate_weights(yhat_est, ys[est], p_unl.argmax(1), p_unl,
                                                       pi, a.boot, rng)
                t_w = time.time() - t_w
                est_w = {"oracle": w_true, **w_est}
                sets, info = M.all_sets(cal_s_true, ys[cal], C.lac_scores(p_ev), est_w, boots, pi,
                                        a.alpha, delta=a.bc_delta)
                tgt_acc = float((p_ev.argmax(1) == y[ev]).mean())
                for meth, S in sets.items():
                    key = meth.replace("wcp_", "")
                    r = C.evaluate(S, y[ev])
                    r.update(dataset="covtype_full", shift=f"area:{AREAS[tgt]}", seed=s, draw=d,
                             method=meth, alpha=a.alpha, score="lac", model="logreg",
                             m_unlab=a.m_unlab, n_cal=len(cal), acc=src_acc, target_acc=tgt_acc,
                             tv_true_shift=W.tv_error(np.ones(K), w_true, pi),
                             tv_err=W.tv_error(est_w[key], w_true, pi) if key in est_w else np.nan,
                             kappa=kap.get(key, np.nan), t_weights=t_w,
                             **info.get(meth, {"bc_t": np.nan, "bc_fallback": np.nan}))
                    rows.append(r)
            print(f"target {AREAS[tgt]} seed {s}: source acc={src_acc:.3f} "
                  f"{time.time() - t0:.1f}s (total {time.time() - t_start:.0f}s)", flush=True)
            pd.DataFrame(rows).to_csv(a.out, index=False)
    print(f"done: {len(rows)} rows -> {a.out} in {time.time() - t_start:.0f}s", flush=True)


if __name__ == "__main__":
    main()
