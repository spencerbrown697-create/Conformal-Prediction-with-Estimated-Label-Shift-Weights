#!/usr/bin/env bash
# Revision 3, queue B: ablations re-run with the current code.
set -euo pipefail
D3="satimage letter covtype"
python scripts/run_experiments.py --datasets $D3 --model hgb --shifts none dir1 dir0.1 --seeds 5 --out results/abl_hgb.csv
python scripts/run_experiments.py --datasets covtype --model hgb_es --shifts none dir1 dir0.1 --seeds 5 --out results/abl_hgb_es_covtype.csv
python scripts/run_experiments.py --datasets $D3 --model logreg --shifts dir1 --alpha 0.2 --seeds 5 --out results/abl_alpha0.2.csv
echo "queue B done"
