"""Recompute every specific number quoted in Sections 6 and 8 of the paper, so
the prose can be checked against the result files.

    python scripts/claims_numbers.py > results/tables/claims_numbers.txt
"""
import numpy as np
import pandas as pd

T = "results/tables"
s = pd.read_csv(f"{T}/main_summary.csv")
m = pd.read_csv("results/main_logreg.csv")
SH = ["dir10", "dir1", "dir0.1"]


def v(ds, sh, meth, col):
    return s[(s.dataset == ds) & (s["shift"] == sh) & (s.method == meth)][f"{col}_mean"].iloc[0]


def rng(ds, shifts, meth, col, d=3):
    x = [v(ds, sh, meth, col) for sh in shifts]
    return f"{min(x):.{d}f}-{max(x):.{d}f}"


print("accuracy", m.groupby("dataset").acc.mean().round(3).to_dict())
print("t_weights per draw (s)", m.groupby("dataset").t_weights.mean().round(2).to_dict())
print("\n== 6.1 SCP")
for ds in ["covtype", "satimage", "letter"]:
    print(ds, "SCP cov", rng(ds, SH, "scp", "coverage"), "worst", rng(ds, SH, "scp", "worst_class_cov"),
          "undercov", rng(ds, SH, "scp", "undercov", 2))
for ds in ["digits", "pendigits"]:
    print(ds, "SCP cov Dir(0.1)", round(v(ds, "dir0.1", "scp", "coverage"), 3))
print("\n== 6.2")
allsh = ["none"] + SH
mo = s[s.method == "mondrian"]
print("Mondrian cov range", mo.coverage_mean.min().round(3), mo.coverage_mean.max().round(3),
      "worst range", mo.worst_class_cov_mean.min().round(3), mo.worst_class_cov_mean.max().round(3),
      "undercov max", mo.undercov_mean.max().round(2), mo.loc[mo.undercov_mean.idxmax(), ["dataset", "shift"]].tolist())
for meth in ["wcp_oracle", "wcp_mlls", "wcp_mlls_js"]:
    x = s[s.method == meth]
    print(meth, "cov range", x.coverage_mean.min().round(3), x.coverage_mean.max().round(3))
print("BBSE covtype shift cov", rng("covtype", SH, "wcp_bbse", "coverage"))
for ds in ["letter", "pendigits", "digits", "satimage"]:
    d = [v(ds, sh, "wcp_mlls_js", "size") - v(ds, sh, "mondrian", "size") for sh in allsh]
    print(ds, "size MLLS-S - Mondrian per shift", np.round(d, 3))
print("letter Dir(1) sizes MLLS-S/Mondrian", round(v("letter", "dir1", "wcp_mlls_js", "size"), 2), round(v("letter", "dir1", "mondrian", "size"), 2))
print("covtype shift sizes oracle", rng("covtype", SH, "wcp_oracle", "size", 2), "mondrian", rng("covtype", SH, "mondrian", "size", 2),
      "worst oracle", rng("covtype", SH, "wcp_oracle", "worst_class_cov"), "worst mondrian", rng("covtype", SH, "mondrian", "worst_class_cov"))
print("covtype none sizes MLLS-S/Mondrian", round(v("covtype", "none", "wcp_mlls_js", "size"), 2), round(v("covtype", "none", "mondrian", "size"), 2))
print("\n== 6.3")
p = s.pivot_table(index=["dataset", "shift"], columns="method", values="tv_err_mean")
print("MLLS better than BBSE in", int((p.wcp_mlls < p.wcp_bbse).sum()), "of", len(p))
print("covtype TV shift MLLS", rng("covtype", SH, "wcp_mlls", "tv_err"), "BBSE", rng("covtype", SH, "wcp_bbse", "tv_err"))
print("covtype undercov shift BBSE", rng("covtype", SH, "wcp_bbse", "undercov", 2), "MLLS", rng("covtype", SH, "wcp_mlls", "undercov", 2),
      "oracle", rng("covtype", SH, "wcp_oracle", "undercov", 2))
for meth in ["wcp_mlls_js", "wcp_bbse_js"]:
    print(meth, "kappa medians", m[m.method == meth].groupby("shift").kappa.median().round(3).to_dict())
for raw in ["wcp_mlls", "wcp_bbse"]:
    x = p.xs("none", level="shift")
    print(raw, "TV none raw", x[raw].min().round(3), x[raw].max().round(3), "shrunk", x[raw + "_js"].min().round(3), x[raw + "_js"].max().round(3))
for ds in ["satimage", "covtype"]:
    print(ds, "undercov none", {k: round(v(ds, "none", k, "undercov"), 2) for k in ["wcp_mlls", "wcp_mlls_js", "wcp_bbse", "wcp_bbse_js"]})
t = pd.read_csv(f"{T}/main_tests.csv")
for ds, sh in [("satimage", "dir10"), ("covtype", "dir1"), ("covtype", "dir10")]:
    r = t[(t.dataset == ds) & (t["shift"] == sh) & (t.ours == "wcp_bbse_js") & (t.ref == "wcp_bbse") & (t.metric == "coverage")].iloc[0]
    print("BBSE-S - BBSE coverage", ds, sh, round(r.mean_diff, 4), [round(r.ci_lo, 4), round(r.ci_hi, 4)])
x = t[(t.ours == "wcp_mlls_js") & (t.ref == "wcp_mlls") & (t.metric == "coverage") & (t["shift"] != "none")]
print("MLLS-S - MLLS coverage under shift: min/max diff", round(x.mean_diff.min(), 4), round(x.mean_diff.max(), 4))
print("pooled post hoc:\n", pd.read_csv(f"{T}/main_pooled_posthoc.csv").round(4).to_string())
print("\n== 6.4 tests per metric", t.groupby("metric").size().to_dict(), "min holm", t.p_holm.min())
print("letter size diffs MLLS-S vs Mondrian:", t[(t.dataset == "letter") & (t.ours == "wcp_mlls_js") & (t.ref == "mondrian") & (t.metric == "size")][["shift", "mean_diff", "ci_lo", "ci_hi", "p_raw"]].round(4).to_string(index=False))
print("\n== 6.5 bound")
b = pd.read_csv(f"{T}/main_bound.csv")
print("mean shortfall", b.mean_shortfall.min().round(3), b.mean_shortfall.max().round(3), "mean tv", b.mean_tv.min().round(3), b.mean_tv.max().round(3))
print("frac excess>2se max", b.frac_excess_gt_2se.max().round(3), b.loc[b.frac_excess_gt_2se.idxmax(), ["dataset", "method"]].tolist())
print("corr>0", int((b.corr_tv_shortfall > 0).sum()), "of", len(b), "max", b.corr_tv_shortfall.max().round(3), b.loc[b.corr_tv_shortfall.idxmax(), ["dataset", "method"]].tolist())
print("covtype bbse tv/shortfall", b[(b.dataset == "covtype") & (b.method == "wcp_bbse")][["mean_tv", "mean_shortfall"]].round(3).values.tolist())
