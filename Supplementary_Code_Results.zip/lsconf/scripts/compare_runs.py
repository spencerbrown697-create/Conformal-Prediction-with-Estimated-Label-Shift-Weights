"""Numerical-sensitivity check: compare two runs of the same configuration that
differ only in the BLAS thread count (Section 8.3 of the paper).

    python scripts/compare_runs.py results/main_logreg_multithreadBLAS.csv results/main_logreg.csv

Writes results/tables/blas_sensitivity.csv: per dataset and method, the mean
and maximum absolute per-draw difference in coverage and TV weight error, and
the largest difference in classifier accuracy.
"""
import os
import sys

import pandas as pd

a, b = pd.read_csv(sys.argv[1]), pd.read_csv(sys.argv[2])
key = ["dataset", "seed", "shift", "draw", "method"]
j = a.merge(b, on=key, suffixes=("_a", "_b"))
j["d_cov"] = (j.coverage_a - j.coverage_b).abs()
j["d_tv"] = (j.tv_err_a - j.tv_err_b).abs()
j["d_acc"] = (j.acc_a - j.acc_b).abs()
out = j.groupby(["dataset", "method"]).agg(
    max_acc_diff=("d_acc", "max"), mean_abs_dcov=("d_cov", "mean"), max_abs_dcov=("d_cov", "max"),
    mean_abs_dtv=("d_tv", "mean"), max_abs_dtv=("d_tv", "max")).reset_index()
os.makedirs("results/tables", exist_ok=True)
out.to_csv("results/tables/blas_sensitivity.csv", index=False)
print(f"{len(j)} matched rows")
print(out.round(4).to_string())
