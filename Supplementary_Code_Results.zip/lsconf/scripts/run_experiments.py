"""Run the label-shift conformal experiments and write one CSV row per
(dataset, seed, shift, draw, method).

Main experiment (Table 2-4 in the paper):
    python scripts/run_experiments.py --out results/main.csv

Ablations (Section 6) use the same script with different flags; see
scripts/run_all.sh for the exact commands used in the paper.
"""
from __future__ import annotations

import os

# Pin BLAS/OpenMP to one thread BEFORE numpy is imported. Multi-threaded BLAS
# changes the logistic-regression fit in the last few digits, and BBSE on
# Covertype is ill-conditioned enough to amplify that (see paper, Sec. 8.3).
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import argparse  # noqa: E402
import platform  # noqa: E402
import sys
import time  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import sklearn  # noqa: E402
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from lsconf import conformal as C  # noqa: E402
from lsconf import methods as M  # noqa: E402
from lsconf import weights as W  # noqa: E402
from lsconf.data import DATASETS, load_dataset, split_source  # noqa: E402
from lsconf.shift import SHIFTS, draw_target_proportions, sample_by_class  # noqa: E402


def make_model(name: str, seed: int):
    if name == "hgb":
        return HistGradientBoostingClassifier(max_iter=200, learning_rate=0.1,
                                              early_stopping=False, random_state=seed)
    if name == "hgb_es":  # post-hoc fix: early stopping (Sec. 7.4)
        return HistGradientBoostingClassifier(max_iter=200, learning_rate=0.1, early_stopping=True,
                                              validation_fraction=0.1, n_iter_no_change=10,
                                              random_state=seed)
    if name == "logreg":
        return make_pipeline(StandardScaler(), LogisticRegression(max_iter=3000, C=1.0))
    raise ValueError(name)


def parse():
    p = argparse.ArgumentParser()
    p.add_argument("--datasets", nargs="+", default=DATASETS)
    p.add_argument("--seeds", type=int, default=10)
    p.add_argument("--seed-offset", type=int, default=0)
    p.add_argument("--draws", type=int, default=10, help="shift draws per seed")
    p.add_argument("--shifts", nargs="+", default=list(SHIFTS))
    p.add_argument("--alpha", type=float, default=0.1)
    p.add_argument("--score", choices=["lac", "aps"], default="lac")
    p.add_argument("--model", choices=["hgb", "hgb_es", "logreg"], default="hgb")
    p.add_argument("--m-unlab", type=int, default=500, help="unlabelled target sample size")
    p.add_argument("--m-eval", type=int, default=2000, help="labelled target test size")
    p.add_argument("--boot", type=int, default=100, help="bootstrap replicates for shrinkage")
    p.add_argument("--kappas", nargs="*", type=float, default=[],
                   help="extra fixed-shrinkage BBSE variants (ablation)")
    p.add_argument("--no-mlls", action="store_true")
    p.add_argument("--bc-delta", type=float, default=0.1,
                   help="bootstrap quantile level for bound-corrected WCP")
    p.add_argument("--out", required=True)
    return p.parse_args()


def main():
    a = parse()
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    print(f"threads OMP={os.environ['OMP_NUM_THREADS']} | python {platform.python_version()} | numpy {np.__version__} | "
          f"sklearn {sklearn.__version__} | {platform.platform()}", flush=True)
    print(vars(a), flush=True)
    rows = []
    t_start = time.time()
    for ds in a.datasets:
        X, y = load_dataset(ds)
        K = int(y.max()) + 1
        for s in range(a.seed_offset, a.seed_offset + a.seeds):
            t0 = time.time()
            tr, est, cal, pool = split_source(X, y, seed=1000 * s)
            model = make_model(a.model, s).fit(X[tr], y[tr])
            pi = np.bincount(y[tr], minlength=K) / len(tr)
            p_est = model.predict_proba(X[est])
            p_cal = model.predict_proba(X[cal])
            p_pool = model.predict_proba(X[pool])
            acc = float((p_pool.argmax(1) == y[pool]).mean())
            yhat_est = p_est.argmax(1)
            rng_score = np.random.default_rng(10_000 + s)
            if a.score == "lac":
                cal_S, pool_S = C.lac_scores(p_cal), C.lac_scores(p_pool)
            else:
                cal_S, pool_S = C.aps_scores(p_cal, rng_score), C.aps_scores(p_pool, rng_score)
            cal_s_true = cal_S[np.arange(len(cal)), y[cal]]
            pool_pos = {int(i): j for j, i in enumerate(pool)}  # global idx -> pool row

            for sh in a.shifts:
                for d in range(a.draws):
                    rng = np.random.default_rng([s, list(SHIFTS).index(sh), d])
                    q = draw_target_proportions(pi, sh, rng)
                    w_true = W.normalise(q / pi, pi)
                    unl, _ = sample_by_class(pool, y[pool], q, a.m_unlab, rng)
                    ev, _ = sample_by_class(pool, y[pool], q, a.m_eval, rng)
                    r_unl = np.fromiter((pool_pos[i] for i in unl), int)
                    r_ev = np.fromiter((pool_pos[i] for i in ev), int)
                    yhat_unl = p_pool[r_unl].argmax(1)

                    t_w = time.time()
                    w_est, boots, kap = M.estimate_weights(
                        yhat_est, y[est], yhat_unl, p_pool[r_unl], pi, a.boot, rng,
                        kappas=a.kappas, no_mlls=a.no_mlls)
                    t_w = time.time() - t_w
                    est_w = {"oracle": w_true, **w_est}

                    test_S, y_ev = pool_S[r_ev], y[ev]
                    sets, info = M.all_sets(cal_s_true, y[cal], test_S, est_w, boots, pi,
                                            a.alpha, delta=a.bc_delta)

                    for meth, S in sets.items():
                        key = meth.replace("wcp_", "")
                        r = C.evaluate(S, y_ev)
                        r.update(dataset=ds, seed=s, shift=sh, draw=d, method=meth,
                                 alpha=a.alpha, score=a.score, model=a.model,
                                 m_unlab=a.m_unlab, n_cal=len(cal), acc=acc,
                                 tv_true_shift=W.tv_error(np.ones(K), w_true, pi),
                                 tv_err=W.tv_error(est_w[key], w_true, pi) if key in est_w else np.nan,
                                 kappa=kap.get(key, np.nan), t_weights=t_w,
                                 **info.get(meth, {"bc_t": np.nan, "bc_fallback": np.nan}))
                        rows.append(r)
            print(f"{ds} seed {s}: acc={acc:.3f} n_cal={len(cal)} "
                  f"{time.time() - t0:.1f}s (total {time.time() - t_start:.0f}s)", flush=True)
            pd.DataFrame(rows).to_csv(a.out, index=False)  # checkpoint
    pd.DataFrame(rows).to_csv(a.out, index=False)
    print(f"done: {len(rows)} rows -> {a.out} in {time.time() - t_start:.0f}s", flush=True)


if __name__ == "__main__":
    main()
