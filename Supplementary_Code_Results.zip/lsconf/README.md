# lsconf — Conformal prediction under label shift with estimated, shrunk and bound-corrected weights

Code, seeds and raw results for the paper

> S. Brown, C. Zhang, W. Huang, X. Song. *Conformal Prediction with Estimated Label-Shift Weights: A Coverage Bound, Bound-Corrected Weighting, and Evidence from Simulated and Natural Shift.* Manuscript submitted to *Artificial Intelligence*, [YEAR].

Every table and figure in the paper is generated from the CSV files in `results/` by the scripts in `scripts/`. Nothing in the paper was typed in by hand.

## Repository layout

```
lsconf/
├── lsconf/                 # library code
│   ├── data.py             # dataset loading + stratified train/est/cal/pool split
│   ├── shift.py            # Dirichlet label-shift simulation
│   ├── weights.py          # BBSE, MLLS (EM), bootstrap shrinkage, TV error
│   ├── methods.py          # weight estimation + all CP methods incl. bound-corrected WCP (BC)
│   └── conformal.py        # LAC/APS scores; split, Mondrian and weighted CP; metrics
├── scripts/
│   ├── run_experiments.py  # one CSV row per (dataset, seed, shift, draw, method)
│   ├── run_natural_shift.py # natural shift: leave-one-wilderness-area-out on full Covertype
│   ├── analyze.py          # seed-level summaries, Wilcoxon + Holm, bootstrap CIs, bound check
│   ├── make_figures.py     # Figures 1-5 (PNG + TIFF, 300 dpi)
│   ├── make_tables.py      # all manuscript tables -> paper/tables_generated.md
│   ├── compare_runs.py     # BLAS-threading sensitivity check (Table 12)
│   ├── claims_numbers.py   # recomputes every number quoted in the text
│   ├── check_consistency.py # checks row counts, method sets, tables, figures, citations
│   └── run_all.sh          # reproduces everything
├── results/                # raw CSVs, logs, tables/ (summaries and tests)
├── figures/                # generated figures
├── paper/                  # manuscript sources (part*.md), refs.bib, build_docx.py, build_latex.py, verify_refs.py
├── requirements.txt
├── environment.yml
├── CITATION.cff
└── LICENSE                 # MIT
```

## 1. Environment

Tested on Windows 10 Pro (build 19045), Python 3.11.7, Intel Core i3-6006U (2 cores), 4 GB RAM, no GPU. The code is pure NumPy and scikit-learn, so it should run unchanged on Linux and macOS.

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

or `conda env create -f environment.yml && conda activate lsconf`.

## 2. Data

No manual download is needed. On first use, scikit-learn fetches and caches the data in `~/scikit_learn_data` (about 13 MB in total):

| Name | How it is loaded | Original source |
|---|---|---|
| digits | `sklearn.datasets.load_digits` (bundled) | https://archive.ics.uci.edu/dataset/80 |
| pendigits | `fetch_openml(data_id=32)` | https://www.openml.org/d/32 |
| satimage | `fetch_openml(data_id=182)` | https://www.openml.org/d/182 |
| letter | `fetch_openml(data_id=6)` | https://www.openml.org/d/6 |
| covtype | `fetch_covtype()`, stratified 30k subsample, seed 0 | https://archive.ics.uci.edu/dataset/31 |

If you get an SSL certificate error during download, point Python to the certifi bundle first:
`export SSL_CERT_FILE=$(python -m certifi)` (PowerShell: `$env:SSL_CERT_FILE = (python -m certifi)`).

## 3. Reproduce everything

```bash
bash scripts/run_all.sh
```

The script runs the main experiment, all ablations, the analysis and the figures. Expected time on the test laptop: about 2.5–3 hours for everything (main experiment 44 min, ablations about 1 h 50 min). Peak memory stays below 1 GB.

### Individual steps

```bash
# Main experiment: 5 datasets x 30 seeds x 4 shift levels x 10 draws x 9 methods = 54,000 rows
python scripts/run_experiments.py --model logreg --seeds 30 --draws 10 --out results/main_logreg.csv
# (equivalently in parallel blocks: --seeds 10 --seed-offset 0/10/20, then concatenate; seeds are independent)

# Natural shift (leave one wilderness area out, full Covertype): 3 areas x 10 seeds x 10 draws x 9 methods
python scripts/run_natural_shift.py --seeds 10 --draws 10 --out results/natural_covtype.csv

# Example ablation: unlabelled target sample size
python scripts/run_experiments.py --datasets satimage letter covtype --model logreg \
       --shifts none dir1 --m-unlab 100 --seeds 5 --out results/abl_m100.csv

# Statistics and figures
python scripts/analyze.py results/main_logreg.csv --tag main
python scripts/make_figures.py
python scripts/make_tables.py
python scripts/check_consistency.py   # must report 0 failures
```

Main options of `run_experiments.py`: `--model {logreg,hgb,hgb_es}`, `--score {lac,aps}`, `--alpha`, `--m-unlab`, `--m-eval`, `--boot`, `--kappas` (fixed-shrinkage variants), `--shifts` (any of `none dir10 dir1 dir0.1`), `--seeds`, `--draws`.

**Numerical note.** `run_experiments.py` pins OpenMP/BLAS to one thread before importing NumPy. Multi-threaded BLAS changes the logistic-regression fit in the last digits, and BBSE on Covertype amplifies this into coverage changes of up to 0.68 in single draws (paper, Section 8.3). Keep the default if you want to reproduce the CSVs exactly.

## 4. Seeds

* Data split for seed index `s`: `random_state = 1000*s` (stratified), `s = 0..29` (main), `0..9` (natural shift) or `0..4` (ablations).
* Gradient boosting `random_state = s`; logistic regression is deterministic.
* Shift draw `d` of shift level `j`: `numpy.random.default_rng([s, j, d])`, which drives the Dirichlet draw, the multinomial class counts, the sampling of target points and the bootstrap.
* APS randomisation: `default_rng(10000 + s)`.
* Covertype subsample: `random_state = 0`.

## 5. Output format

Each row of a results CSV contains: `dataset, seed, shift, draw, method, coverage, size, worst_class_cov, empty_rate, alpha, score, model, m_unlab, n_cal, acc, tv_true_shift, tv_err, kappa, t_weights`.

## 6. Use the method on your own data

```python
import numpy as np
from lsconf import weights as W, conformal as C

# p_est, y_est: probabilities and labels on a labelled source hold-out
# p_cal, y_cal: calibration set;  p_tgt: unlabelled target data;  pi: source class proportions
w = W.mlls(p_tgt, pi)
boot = W.bootstrap_mlls(p_tgt, pi, B=100, rng=np.random.default_rng(0))
w_s, kappa = W.js_shrink(w, boot, pi)

cal_scores = C.lac_scores(p_cal)[np.arange(len(y_cal)), y_cal]
sets = C.weighted_cp(cal_scores, y_cal, C.lac_scores(p_test), w_s, alpha=0.1)
```

## 7. Citation

If you use this code, please cite the paper (see `CITATION.cff`):

```bibtex
@article{lsconf2026,
  author  = {Brown, Spencer and Zhang, Chen and Huang, Wu and Song, Xie},
  title   = {Conformal Prediction with Estimated Label-Shift Weights: A Coverage Bound, Bound-Corrected Weighting, and Evidence from Simulated and Natural Shift},
  journal = {Artificial Intelligence},
  year    = {2026},
  note    = {Under review}
}
```

and the software archive: `[INSERT ZENODO DOI after archiving the repository]`.

## License

MIT; see `LICENSE`. The datasets keep their original licences: UCI datasets are CC BY 4.0, and OpenML lists the licence for each dataset.
